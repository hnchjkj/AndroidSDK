package com.hncj.sdk.service.network.model.req

import androidx.annotation.Keep

/**
 * date：2026-01-22 9:43
 * desc：
 */
@Keep
internal class InsertFeedbackReq {
    var title: String? = null
    var content: String? = null
    var pictureList: List<String>? = null
    var feedBackType: Int = 0
}