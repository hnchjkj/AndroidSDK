package com.hncj.sdk.service.network.model.resp

import androidx.annotation.Keep

/**
 * date：2026-01-17 10:47
 * desc：
 */
@Keep
internal data class QueryFeedbackResp(
    val total: Int,
    val list: ArrayList<QueryFeedbackItem>
)

@Keep
internal data class QueryFeedbackItem(
    val content: String, // 意见反馈内容
    val createTime: String, // 创建时间
    val feedbackType: Int, // 反馈类型 1：登陆问题 2：支付问题 3：优化建议 0：其他
    val id: Int, // 意见id
    val pictureList: ArrayList<String>, // 附件列表
    val replayContent: String, // 回复内容
    val status: Int, // 意见状态 0：未处理 1：已处理
    val title: String, // 反馈标题
    val type: Int, // 标识 0：用户反馈，1：管理员回复
    val userId: Long, // 所属用户id
    val userName: String // 所属用户昵称
)