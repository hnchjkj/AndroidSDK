package com.hncj.sdk.service;

@androidx.databinding.BindingBuildInfo
public class DataBindingTriggerClass {}