package com.hncj.sdk.service.network.service

import com.hncj.sdk.service.network.model.BaseResponse
import com.hncj.sdk.service.network.model.req.InsertFeedbackReq
import com.hncj.sdk.service.network.model.resp.GetCredentialResp
import com.hncj.sdk.service.network.model.resp.GetFeedbackDetailResp
import com.hncj.sdk.service.network.model.resp.QueryFeedbackResp
import retrofit2.http.Body
import retrofit2.http.Field
import retrofit2.http.FieldMap
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

internal interface ApiService {

    /**
     * 获取凭证
     */
    @FormUrlEncoded
    @POST("/basic/file/aws/upload")
    suspend fun getCredential(@FieldMap params: HashMap<String, String>): BaseResponse<GetCredentialResp>

    /**
     * 添加反馈
     */
    @POST("/basic/feedback/insert")
    suspend fun insertFeedback(@Body req:InsertFeedbackReq): BaseResponse<Boolean>

    /**
     * 查询反馈
     */
    @FormUrlEncoded
    @POST("/basic/feedback/query")
    suspend fun queryFeedback(@FieldMap params: HashMap<String, Any>): BaseResponse<QueryFeedbackResp>

    /**
     * 查询反馈详情
     */
    @FormUrlEncoded
    @POST("/basic/feedback/getDetail")
    suspend fun getFeedbackDetail(@FieldMap params: HashMap<String, Any>): BaseResponse<GetFeedbackDetailResp>
}