package com.hncj.sdk.service.ui.activity

import android.content.Context
import android.content.Intent
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.hncj.sdk.service.R
import com.hncj.sdk.service.databinding.ActivityFeedbackDetailBinding
import com.hncj.sdk.core.ext.onThrottleClick
import com.hncj.sdk.core.ext.toast
import com.hncj.sdk.core.ui.BaseActivity
import com.hncj.sdk.service.network.RequestClient
import com.hncj.sdk.service.network.Result
import com.hncj.sdk.service.ui.adapter.FeedbackDetailImageAdapter
import com.hncj.sdk.service.utils.GlideEngine
import com.luck.picture.lib.basic.PictureSelector
import com.luck.picture.lib.entity.LocalMedia
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal class FeedbackDetailActivity : BaseActivity<ActivityFeedbackDetailBinding>() {

    companion object {
        fun start(context: Context, id: Int) {
            context.startActivity(
                Intent(context, FeedbackDetailActivity::class.java).apply {
                    putExtra("id", id)
                }
            )
        }
    }

    private val mAdapter = FeedbackDetailImageAdapter()

    override fun initViews() {
        mDataBinding.apply {
            mustBackAny.onThrottleClick {
                finish()
            }

            mustRecyclerView.apply {
                layoutManager = GridLayoutManager(this@FeedbackDetailActivity, 3)
                adapter = mAdapter
            }
        }

        mAdapter.setOnItemClickListener { adapter, view, position ->
            val listLocalMedia = arrayListOf<LocalMedia>()
            mAdapter.data.forEach {
                listLocalMedia.add(
                    LocalMedia.generateLocalMedia(this@FeedbackDetailActivity, it)
                )
            }
            PictureSelector.create(this@FeedbackDetailActivity)
                .openPreview()
                .setImageEngine(GlideEngine.createGlideEngine())
                .startActivityPreview(position, false, listLocalMedia)
        }

        loadData()
    }

    private fun loadData() {
        val id = intent.getIntExtra("id", -1)
        if (id == -1) {
            toast(getString(R.string.feedback_get_detail_params_fail))
            finish()
            return
        }
        lifecycleScope.launch {
            when (val result = RequestClient.repository.getFeedbackDetail(id)) {
                is Result.Success -> {
                    val child = result.data.child
                    if (child.isEmpty()) {
                        toast(getString(R.string.feedback_get_detail_fail))
                        finish()
                        return@launch
                    }
                    val data = child[0]
                    withContext(Dispatchers.Main) {
                        mDataBinding.mustDetailTv.text = data.content
                        mAdapter.setList(data.pictureList)
                    }
                }

                is Result.Error -> {
                    toast(getString(R.string.feedback_get_detail_fail))
                }

                else -> {}
            }
        }
    }

    override fun statusBarDarkFont(): Boolean {
        return true
    }

    override fun initDataObserver() {}

    override fun getLayoutId(): Int {
        return R.layout.activity_feedback_detail
    }
}