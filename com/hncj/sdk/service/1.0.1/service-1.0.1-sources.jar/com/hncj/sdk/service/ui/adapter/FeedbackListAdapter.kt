package com.hncj.sdk.service.ui.adapter

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.listener.OnItemClickListener
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.hncj.sdk.service.R
import com.hncj.sdk.core.ext.gone
import com.hncj.sdk.core.ext.visible
import com.hncj.sdk.service.network.model.resp.QueryFeedbackItem
import com.hncj.sdk.service.utils.GlideEngine
import com.luck.picture.lib.basic.PictureSelector
import com.luck.picture.lib.entity.LocalMedia
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * date：2026-01-16 14:15
 * desc：
 */
internal class FeedbackListAdapter :
    BaseQuickAdapter<QueryFeedbackItem, BaseViewHolder>(R.layout.item_feedback_list) {

    override fun convert(holder: BaseViewHolder, item: QueryFeedbackItem) {
        val must_reply_any = holder.getViewOrNull<View>(R.id.must_reply_any)
        val must_reply_detail_tv = holder.getViewOrNull<TextView>(R.id.must_reply_detail_tv)
        val must_title_tv = holder.getViewOrNull<TextView>(R.id.must_title_tv)
        val must_detail_tv = holder.getViewOrNull<TextView>(R.id.must_detail_tv)
        val must_recycler_view = holder.getViewOrNull<RecyclerView>(R.id.must_recycler_view)
        val must_time_tv = holder.getViewOrNull<TextView>(R.id.must_time_tv)

        must_title_tv?.text = item.title
        must_detail_tv?.text = item.content
        must_time_tv?.text = item.createTime

        must_reply_any?.let {
            if (item.status == 0) {
                it.gone()
                must_reply_detail_tv?.text = ""
            } else {
                it.visible()
                must_reply_detail_tv?.text = item.replayContent
            }
        }

        must_recycler_view?.apply {
            val feedbackListChildAdapter = FeedbackListChildAdapter()
            layoutManager = GridLayoutManager(context, 3)
            adapter = feedbackListChildAdapter
            feedbackListChildAdapter.setList(item.pictureList)
            feedbackListChildAdapter.setOnItemClickListener { adapter, view, position ->
                val listLocalMedia = arrayListOf<LocalMedia>()
                item.pictureList.forEach {
                    listLocalMedia.add(
                        LocalMedia.generateLocalMedia(context, it)
                    )
                }
                PictureSelector.create(context)
                    .openPreview()
                    .setImageEngine(GlideEngine.createGlideEngine())
                    .startActivityPreview(position, false, listLocalMedia)
            }
        }
    }
}

internal class FeedbackListChildAdapter :
    BaseQuickAdapter<String, BaseViewHolder>(R.layout.item_feedback_list_child) {

    override fun convert(holder: BaseViewHolder, item: String) {
        val must_image_iv = holder.getViewOrNull<ImageView>(R.id.must_image_iv)

        must_image_iv?.let {
            Glide.with(it)
                .load(item)
                .into(it)
        }
    }
}