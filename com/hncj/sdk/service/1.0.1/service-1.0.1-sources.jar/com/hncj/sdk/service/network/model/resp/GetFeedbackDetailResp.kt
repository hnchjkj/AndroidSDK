package com.hncj.sdk.service.network.model.resp

import androidx.annotation.Keep

/**
 * date：2026-01-22 12:41
 * desc：
 */
@Keep
internal data class GetFeedbackDetailResp(
    val child: ArrayList<GetFeedbackDetailChildItem>,
    val content: String,
    val feedbackType: Int,
    val id: Int,
    val pictureList: ArrayList<String>,
    val status: Int,
    val title: String,
    val type: Int,
    val userId: Long,
    val userName: String
)

@Keep
internal data class GetFeedbackDetailChildItem(
    val content: String,
    val feedbackType: Int,
    val id: Int,
    val pictureList: ArrayList<String>,
    val status: Int,
    val title: String,
    val type: Int,
    val userId: Int,
    val userName: String
)