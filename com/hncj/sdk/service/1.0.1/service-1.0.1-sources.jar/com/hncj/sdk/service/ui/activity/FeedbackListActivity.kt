package com.hncj.sdk.service.ui.activity

import android.content.Context
import android.content.Intent
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.hncj.sdk.service.R
import com.hncj.sdk.service.databinding.ActivityFeedbackListBinding
import com.hncj.sdk.core.ext.onThrottleClick
import com.hncj.sdk.core.ext.toast
import com.hncj.sdk.core.ui.BaseActivity
import com.hncj.sdk.service.network.RequestClient
import com.hncj.sdk.service.network.Result
import com.hncj.sdk.service.ui.adapter.FeedbackListAdapter
import com.scwang.smart.refresh.layout.api.RefreshLayout
import com.scwang.smart.refresh.layout.listener.OnLoadMoreListener
import com.scwang.smart.refresh.layout.listener.OnRefreshListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal class FeedbackListActivity : BaseActivity<ActivityFeedbackListBinding>(),
    OnLoadMoreListener,
    OnRefreshListener {

    companion object {
        fun start(context: Context) {
            context.startActivity(
                Intent(context, FeedbackListActivity::class.java).apply {

                }
            )
        }
    }

    private var mIsLoadMore = false
    private var mPageNum = 1

    private val mAdapter = FeedbackListAdapter()

    override fun initViews() {
        mDataBinding.apply {
            mustBackAny.onThrottleClick {
                finish()
            }

            mustRecyclerView.apply {
                layoutManager = LinearLayoutManager(this@FeedbackListActivity)
                adapter = mAdapter
            }

            mustSmartRefreshLayout.setOnRefreshListener(this@FeedbackListActivity)
            mustSmartRefreshLayout.setOnLoadMoreListener(this@FeedbackListActivity)
            mustSmartRefreshLayout.autoRefresh()
        }

        mAdapter.setEmptyView(R.layout.layout_feedback_empty)
        mAdapter.setOnItemClickListener { adapter, view, position ->
            val data = mAdapter.data[position]
            if (data.status == 0) {
                toast(getString(R.string.feedback_list_reply_empty_toast))
            } else {
                FeedbackDetailActivity.start(this@FeedbackListActivity, data.id)
            }
        }
    }

    private fun loadData() {
        lifecycleScope.launch {
            when (val result = RequestClient.repository.queryFeedback(mPageNum)) {
                is Result.Success -> {
                    withContext(Dispatchers.Main) {
                        if (mIsLoadMore) {
                            mAdapter.addData(result.data.list)
                            mDataBinding.mustSmartRefreshLayout.finishLoadMore()
                        } else {
                            mAdapter.setList(result.data.list)
                            mDataBinding.mustSmartRefreshLayout.finishRefresh()
                        }
                    }
                }

                is Result.Error -> {
                    withContext(Dispatchers.Main) {
                        if (!mIsLoadMore) {
                            mAdapter.setList(arrayListOf())
                            mDataBinding.mustSmartRefreshLayout.finishRefresh()
                        } else {
                            mPageNum--
                            mDataBinding.mustSmartRefreshLayout.finishLoadMore()
                        }
                    }
                }

                else -> {}
            }
        }
    }

    override fun statusBarDarkFont(): Boolean {
        return true
    }

    override fun initDataObserver() {}

    override fun getLayoutId(): Int {
        return R.layout.activity_feedback_list
    }

    override fun onLoadMore(refreshLayout: RefreshLayout) {
        mIsLoadMore = true
        mPageNum++
        loadData()
    }

    override fun onRefresh(refreshLayout: RefreshLayout) {
        mIsLoadMore = false
        mPageNum = 1
        loadData()
    }
}