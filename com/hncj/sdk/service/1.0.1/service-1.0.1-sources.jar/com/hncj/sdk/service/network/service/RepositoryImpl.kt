package com.hncj.sdk.service.network.service

import androidx.annotation.RestrictTo
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.service.network.NetworkFactory
import com.hncj.sdk.service.network.ResultTransformer
import com.hncj.sdk.service.network.Result
import com.hncj.sdk.service.network.model.req.InsertFeedbackReq
import com.hncj.sdk.service.network.model.resp.GetCredentialResp
import com.hncj.sdk.service.network.model.resp.GetFeedbackDetailResp
import com.hncj.sdk.service.network.model.resp.QueryFeedbackResp
import retrofit2.create

@RestrictTo(RestrictTo.Scope.LIBRARY)
internal class RepositoryImpl(url: String) : Repository {

    private val service: ApiService by lazy {
        NetworkFactory.createRetrofit(url).create()
    }

    override suspend fun getCredential(): Result<GetCredentialResp> {
        return ResultTransformer.asResult(
            networkCall = {
                val params = hashMapOf<String, String>().apply {

                }
                service.getCredential(params)
            },
            transformer = { it }
        )
    }

    override suspend fun insertFeedback(
        title: String,
        content: String,
        pictureList: ArrayList<String>
    ): Result<Boolean> {
        return ResultTransformer.asResult(
            networkCall = {
                val req = InsertFeedbackReq().apply {
                    this.title = title
                    this.content = content
                    this.pictureList = pictureList
                }
                service.insertFeedback(req)
            }
        )
    }

    override suspend fun queryFeedback(pageNum:Int): Result<QueryFeedbackResp> {
        return ResultTransformer.asResult(
            networkCall = {
                val params = hashMapOf<String, Any>().apply {
                    put("pageNum", pageNum)
                    put("pageSize", 10)
                    put("feedbackType", 0)
                }
                service.queryFeedback(params)
            },
            transformer = { it }
        )
    }

    override suspend fun getFeedbackDetail(id: Int): Result<GetFeedbackDetailResp> {
        return ResultTransformer.asResult(
            networkCall = {
                val params = hashMapOf<String, Any>().apply {
                    put("feedbackId", id)
                }
                service.getFeedbackDetail(params)
            },
            transformer = { it }
        )
    }
}