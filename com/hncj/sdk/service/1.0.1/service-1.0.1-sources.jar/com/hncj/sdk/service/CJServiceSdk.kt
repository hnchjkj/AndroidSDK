package com.hncj.sdk.service

import android.content.Context
import android.content.Intent
import android.util.Log
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.service.network.RequestClient
import com.hncj.sdk.service.ui.activity.FeedbackActivity
import com.hncj.sdk.service.utils.LOG
import com.tencent.mmkv.MMKV
import com.tencent.mmkv.MMKVLogLevel

/**
 * date：2026-01-07 9:28
 * desc：
 */
object CJServiceSdk {

    var isDebug = false
    var debugLevel = Log.ERROR

    var isInit = false

    fun init() {
        RequestClient.init {
            isInit = true
        }
    }

    fun preInit(
        isDebug: Boolean = false,
        debugLevel: Int = Log.ERROR
    ) {
        this.isDebug = isDebug
        this.debugLevel = debugLevel
        LOG.init()
        MMKV.initialize(Utils.app, MMKVLogLevel.LevelError)
    }

    fun startFeedback(context: Context) {
        if (isInit.not()) {
            LOG.e(LOG.TAG, "please init first")
            return
        }
        context.startActivity(
            Intent(context, FeedbackActivity::class.java)
        )
    }
}