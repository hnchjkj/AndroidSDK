package com.hncj.sdk.service.network.model.resp

import androidx.annotation.Keep

/**
 * date：2026-01-21 15:11
 * desc：
 */
@Keep
internal data class GetCredentialResp(
    val accessKeyId: String,
    val bucketName: String,
    val expiration: String,
    val region: String,
    val secretAccessKey: String,
    val sessionToken: String,
    val uploadUrl: String
)