package com.hncj.sdk.service.ui.adapter

import android.widget.ImageView
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.hncj.sdk.service.R

/**
 * date：2026-01-16 14:15
 * desc：
 */
internal class FeedbackDetailImageAdapter :
    BaseQuickAdapter<String, BaseViewHolder>(R.layout.item_feedback_detail_image) {

    override fun convert(holder: BaseViewHolder, item: String) {
        val must_image_iv = holder.getViewOrNull<ImageView>(R.id.must_image_iv)

        must_image_iv?.let {
            Glide.with(it)
                .load(item)
                .into(it)
        }
    }
}