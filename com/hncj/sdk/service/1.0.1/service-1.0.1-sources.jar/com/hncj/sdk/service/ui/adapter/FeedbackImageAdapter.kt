package com.hncj.sdk.service.ui.adapter

import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.hncj.sdk.service.R
import com.hncj.sdk.core.ext.gone
import com.hncj.sdk.core.ext.visible
import java.io.File

/**
 * date：2026-01-16 14:15
 * desc：
 */
internal class FeedbackImageAdapter :
    BaseQuickAdapter<FeedbackItem, BaseViewHolder>(R.layout.item_feedback_image) {

    override fun convert(holder: BaseViewHolder, item: FeedbackItem) {
        val must_image_iv = holder.getViewOrNull<ImageView>(R.id.must_image_iv)
        val must_delete_any = holder.getViewOrNull<View>(R.id.must_delete_any)

        when (item.type) {
            FeedbackItemType.TYPE_ADD -> {
                must_image_iv?.setImageResource(R.drawable.ic_feedback_add)
                must_delete_any?.gone()
            }

            else -> {
                val file = File(item.filePath)
                must_image_iv?.let {
                    Glide.with(it)
                        .load(file)
                        .into(it)
                }
                must_delete_any?.visible()
            }
        }
    }
}

internal data class FeedbackItem(
    val type: FeedbackItemType,
    val filePath: String = ""
)

internal enum class FeedbackItemType {
    TYPE_ADD,
    TYPE_IMAGE
}