package com.hncj.sdk.service.network.service

import com.hncj.sdk.service.network.Result
import com.hncj.sdk.service.network.model.resp.GetCredentialResp
import com.hncj.sdk.service.network.model.resp.GetFeedbackDetailResp
import com.hncj.sdk.service.network.model.resp.QueryFeedbackResp

internal interface Repository {

    suspend fun getCredential(): Result<GetCredentialResp>

    suspend fun insertFeedback(
        title: String,
        content: String,
        pictureList: ArrayList<String>
    ): Result<Boolean>

    suspend fun queryFeedback(pageNum:Int): Result<QueryFeedbackResp>

    suspend fun getFeedbackDetail(id:Int): Result<GetFeedbackDetailResp>
}