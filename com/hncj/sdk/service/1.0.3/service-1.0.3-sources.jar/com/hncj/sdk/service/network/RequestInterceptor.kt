package com.hncj.sdk.service.network

import android.os.Build
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.ext.gson
import com.hncj.sdk.core.utils.LOG
import com.hncj.sdk.service.utils.EncryptUtils
import okhttp3.FormBody
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okio.Buffer
import java.util.Locale

internal class RequestInterceptor : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()
        if (request.method == "POST") {
            val body = request.body
            val requestBuilder = request.newBuilder()
            if (body != null) {
                val timestamp = System.currentTimeMillis() / 1000L
                val hasTimeUrl = "${request.url}?t=${timestamp}"
                val hasTimePath = "${request.url.encodedPath}?t=${timestamp}"
                val appSecret = ConfigCache.appSecret

                val paramJson = when (body) {
                    is FormBody -> {
                        val hashParam = hashMapOf<String, String>()
                        for (i in 0 until body.size) {
                            hashParam[body.encodedName(i)] = body.encodedValue(i)
                        }
                        gson.toJson(hashParam)
                    }

                    else -> {
                        val buffer = Buffer()
                        body.writeTo(buffer)
                        buffer.readUtf8()
                    }
                }

                LOG.d(
                    LOG.SERVICE_TAG_HTTP,
                    "request -> $paramJson"
                )

                val requestBody = paramJson.toRequestBody(
                    "application/json;charset=utf-8".toMediaTypeOrNull()
                )

                val sign = EncryptUtils.encrypt(hasTimePath, paramJson, appSecret)
                if (sign.isNotEmpty()) {
                    requestBuilder.addHeader("x-sign", sign)
                }
                if (ConfigCache.appKey.isNotEmpty()) {
                    requestBuilder.addHeader("x-appKey", ConfigCache.appKey)
                }
                requestBuilder.addHeader("x-platform", "Android")
                requestBuilder.addHeader("x-area", Locale.getDefault().country)
                if (ConfigCache.token.isNotEmpty()) {
                    requestBuilder.addHeader("Authorization", ConfigCache.token)
                }
                requestBuilder.addHeader("x-device-model", "${Build.MANUFACTURER} ${Build.MODEL}")

                requestBuilder.post(requestBody).url(hasTimeUrl)
                request = requestBuilder.build()
            }
        }

        return chain.proceed(request)
    }
}