package com.hncj.sdk.service

import android.content.Context
import android.content.Intent
import com.hncj.sdk.core.utils.LOG
import com.hncj.sdk.service.network.RequestClient
import com.hncj.sdk.service.ui.activity.FeedbackActivity

/**
 * date：2026-01-07 9:28
 * desc：
 */
object CJServiceSdk {

    var isInit = false

    fun init() {
        RequestClient.init {
            isInit = true
        }
    }

    fun startFeedback(context: Context) {
        if (isInit.not()) {
            LOG.e(LOG.SERVICE_TAG, "please init first")
            return
        }
        context.startActivity(
            Intent(context, FeedbackActivity::class.java)
        )
    }
}