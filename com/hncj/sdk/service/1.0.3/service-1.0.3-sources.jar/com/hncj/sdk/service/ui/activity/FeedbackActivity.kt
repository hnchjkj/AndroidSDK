package com.hncj.sdk.service.ui.activity

import android.content.Context
import android.content.Intent
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.amazonaws.auth.BasicSessionCredentials
import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener
import com.amazonaws.mobileconnectors.s3.transferutility.TransferState
import com.amazonaws.mobileconnectors.s3.transferutility.TransferUtility
import com.amazonaws.regions.Region
import com.amazonaws.services.s3.AmazonS3Client
import com.hncj.sdk.service.R
import com.hncj.sdk.service.databinding.ActivityFeedbackBinding
import com.hjq.permissions.XXPermissions
import com.hjq.permissions.permission.PermissionLists
import com.hncj.sdk.core.ext.onThrottleClick
import com.hncj.sdk.core.ext.toast
import com.hncj.sdk.core.ui.BaseActivity
import com.hncj.sdk.core.utils.LOG
import com.hncj.sdk.core.utils.LoadingDialogHelper
import com.hncj.sdk.service.network.RequestClient
import com.hncj.sdk.service.network.Result
import com.hncj.sdk.service.ui.adapter.FeedbackImageAdapter
import com.hncj.sdk.service.ui.adapter.FeedbackItem
import com.hncj.sdk.service.ui.adapter.FeedbackItemType
import com.hncj.sdk.service.utils.GlideEngine
import com.luck.picture.lib.basic.PictureSelector
import com.luck.picture.lib.config.PictureMimeType
import com.luck.picture.lib.config.SelectMimeType
import com.luck.picture.lib.entity.LocalMedia
import com.luck.picture.lib.interfaces.OnResultCallbackListener
import com.luck.picture.lib.style.BottomNavBarStyle
import com.luck.picture.lib.style.PictureSelectorStyle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

internal class FeedbackActivity : BaseActivity<ActivityFeedbackBinding>() {

    companion object {
        fun start(context: Context) {
            context.startActivity(
                Intent(context, FeedbackActivity::class.java).apply {

                }
            )
        }
    }

    private val mAdapter = FeedbackImageAdapter()
    private val mSelectLocalMedia = arrayListOf<LocalMedia?>()
    private val MAX_IMAGE_NUM = 9

    override fun initViews() {
        mDataBinding.apply {
            mustBackAny.onThrottleClick {
                finish()
            }

            mustHistoryAny.onThrottleClick {
                FeedbackListActivity.start(this@FeedbackActivity)
            }

            mustDetailEt.addTextChangedListener {
                mustSizeTv.text = "${mustDetailEt.text.length}/600"
            }

            mustSubmitAny.onThrottleClick {
                val title = mDataBinding.mustTitleEt.text.toString()
                val detail = mDataBinding.mustDetailEt.text.toString()
                if (title.isEmpty()) {
                    toast(getString(R.string.feedback_title_empty_toast))
                    return@onThrottleClick
                }
                if (detail.isEmpty()) {
                    toast(getString(R.string.feedback_detail_empty_toast))
                    return@onThrottleClick
                }

                val imageFileList = arrayListOf<File>().apply {
                    mAdapter.data.filter { it.type == FeedbackItemType.TYPE_IMAGE }
                        .forEach { item ->
                            add(File(item.filePath))
                        }
                }
                uploadImage(
                    imageFileList,
                    onSuccess = {
                        val loadingDialog =
                            LoadingDialogHelper.getLoadingDialog(this@FeedbackActivity)
                        loadingDialog.show()
                        lifecycleScope.launch(Dispatchers.IO) {
                            when (val result =
                                RequestClient.repository.insertFeedback(title, detail, it)) {
                                is Result.Success -> {
                                    withContext(Dispatchers.Main) {
                                        loadingDialog.dismiss()
                                        toast(getString(R.string.feedback_submit_success_toast))
                                        FeedbackListActivity.start(this@FeedbackActivity)
                                        finish()
                                    }
                                }

                                is Result.Error -> {
                                    withContext(Dispatchers.Main) {
                                        loadingDialog.dismiss()
                                        toast(getString(R.string.feedback_submit_fail_toast))
                                    }
                                }

                                else -> {}
                            }
                        }
                    }
                )
            }

            mustRecyclerView.apply {
                layoutManager = GridLayoutManager(this@FeedbackActivity, 3)
                adapter = mAdapter
            }
        }

        mAdapter.setOnItemClickListener { adapter, view, position ->
            val data = mAdapter.data[position]
            when (data.type) {
                FeedbackItemType.TYPE_ADD -> {
                    pickImage()
                }

                else -> {
                    mAdapter.data.removeAt(position)
                    mSelectLocalMedia.removeAt(position)
                    mAdapter.notifyItemRemoved(position)
                    if (mSelectLocalMedia.size < MAX_IMAGE_NUM) {
                        if (mAdapter.data.find { it.type == FeedbackItemType.TYPE_ADD } == null) {
                            mAdapter.data.add(FeedbackItem(FeedbackItemType.TYPE_ADD))
                            mAdapter.notifyItemInserted(mAdapter.data.size)
                        }
                    }
                }
            }
        }

        mAdapter.setList(arrayListOf(FeedbackItem(FeedbackItemType.TYPE_ADD)))
    }

    private fun uploadImage(
        data: ArrayList<File>,
        onSuccess: (listUrl: ArrayList<String>) -> Unit,
        onFailure: () -> Unit = {}
    ) {
        if (data.isEmpty()) {
            onSuccess.invoke(arrayListOf())
            return
        }
        val loadingDialog = LoadingDialogHelper.getLoadingDialog(
            this@FeedbackActivity,
            getString(R.string.feedback_upload_image_loading)
        )
        loadingDialog.show()
        lifecycleScope.launch(Dispatchers.IO) {
            when (val result = RequestClient.repository.getCredential()) {
                is Result.Success -> {
                    val credentials = BasicSessionCredentials(
                        result.data.accessKeyId,
                        result.data.secretAccessKey,
                        result.data.sessionToken
                    )

                    val s3Client = AmazonS3Client(
                        credentials,
                        Region.getRegion(result.data.region)
                    )

                    val bucket = result.data.bucketName
                    val rootPath = result.data.uploadUrl

                    val result = arrayListOf<String>()

                    val size = data.size
                    var completeSize = 0

                    fun checkComplete() {
                        completeSize++
                        if (completeSize == size) {
                            LOG.d(
                                LOG.SERVICE_TAG,
                                "upload image completed, success: ${result.size}, total: $size"
                            )
                            loadingDialog.dismiss()
                            if (result.size != size) {
                                LOG.e(LOG.SERVICE_TAG, "some image upload failure")
                                onFailure.invoke()
                            } else {
                                onSuccess.invoke(result)
                            }
                        }
                    }

                    try {
                        val transferUtility = TransferUtility.builder()
                            .context(this@FeedbackActivity)
                            .s3Client(s3Client)
                            .build()

                        data.forEachIndexed { index, file ->
                            val key = rootPath + File.separator + file.name

                            LOG.d(LOG.SERVICE_TAG, "start to upload, position: ${index + 1}")

                            val observer = transferUtility.upload(bucket, key, file)

                            observer.setTransferListener(
                                object : TransferListener {
                                    override fun onStateChanged(id: Int, state: TransferState?) {
                                        when (state) {
                                            TransferState.COMPLETED -> {
                                                LOG.d(
                                                    LOG.SERVICE_TAG,
                                                    "upload image completed, position: ${index + 1}"
                                                )
                                                val url = s3Client.getResourceUrl(bucket, key)
                                                result.add(url)
                                                checkComplete()
                                            }

                                            else -> {}
                                        }
                                    }

                                    override fun onProgressChanged(
                                        id: Int,
                                        bytesCurrent: Long,
                                        bytesTotal: Long
                                    ) {
                                    }

                                    override fun onError(id: Int, ex: Exception?) {
                                        ex?.printStackTrace()
                                        LOG.e(
                                            LOG.SERVICE_TAG,
                                            "upload image error, position: ${index + 1}, ${ex?.message}"
                                        )
                                        checkComplete()
                                    }
                                }
                            )
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        LOG.e(LOG.SERVICE_TAG, "upload image exception, ${e.message}")
                        loadingDialog.dismiss()
                        onFailure.invoke()
                    }
                }

                is Result.Error -> {}
                else -> {}
            }
        }
    }

    private fun pickImage() {
        checkPermission {
            PictureSelector.create(this)
                .openGallery(SelectMimeType.ofImage())
                .setImageEngine(GlideEngine.createGlideEngine())
                .isDisplayCamera(false)
                .setSelectorUIStyle(
                    PictureSelectorStyle().apply {
                        bottomBarStyle = BottomNavBarStyle().apply {
                            bottomNarBarHeight = 120
                        }
                    }
                )
                .setSelectMaxFileSize(5 * 1024)
                .setSelectedData(mSelectLocalMedia)
                .setMaxSelectNum(MAX_IMAGE_NUM)
                .isEmptyResultReturn(true) // 支持未选择返回
                .setQueryOnlyMimeType(PictureMimeType.PNG_Q, PictureMimeType.JPEG_Q)
                .forResult(
                    object : OnResultCallbackListener<LocalMedia?> {
                        override fun onResult(result: ArrayList<LocalMedia?>) {
                            mSelectLocalMedia.clear()
                            mSelectLocalMedia.addAll(result)

                            val list = arrayListOf<FeedbackItem>()
                            result.forEach {
                                it?.let { localMedia ->
                                    list.add(
                                        FeedbackItem(
                                            FeedbackItemType.TYPE_IMAGE,
                                            localMedia.realPath
                                        )
                                    )
                                }
                            }
                            if (list.size < MAX_IMAGE_NUM) {
                                list.add(FeedbackItem(FeedbackItemType.TYPE_ADD))
                            }
                            mAdapter.setList(list)
                        }

                        override fun onCancel() {}
                    }
                )
        }
    }

    private fun checkPermission(onGranted: () -> Unit) {
        if (XXPermissions.isGrantedPermission(
                this,
                PermissionLists.getManageExternalStoragePermission()
            )
        ) {
            onGranted.invoke()
        } else {
            XXPermissions.with(this)
                .permission(PermissionLists.getManageExternalStoragePermission())
                .request { grantedList, deniedList ->
                    val allGranted = deniedList.isEmpty()
                    if (allGranted) {
                        onGranted.invoke()
                    } else {
                        toast(getString(R.string.feedback_permission_denied_toast))
                    }
                }
        }
    }

    override fun statusBarDarkFont(): Boolean {
        return true
    }

    override fun initDataObserver() {}

    override fun getLayoutId(): Int {
        return R.layout.activity_feedback
    }
}