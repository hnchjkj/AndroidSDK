package com.hncj.sdk.login.repository.impl

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.Credential
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.ClearCredentialException
import androidx.credentials.exceptions.GetCredentialException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.OAuthCredential
import com.google.firebase.auth.auth
import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.api.ThirdAuthResult
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

internal class GoogleAuthProviderImp(
    private val context: Context,
//    private val lifecycleOwner: LifecycleOwner,
    private val serverClientId: String
) {

    private val auth: FirebaseAuth = Firebase.auth
    private val credentialManager: CredentialManager =
        CredentialManager.create(context as Activity)

    fun signIn(callback: SignInCallback) {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setServerClientId(serverClientId)
            .setFilterByAuthorizedAccounts(false)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        MainScope().launch {
            try {
                val result = credentialManager.getCredential(
                    context = context as Activity,
                    request = request
                )
                handleCredential(result.credential, callback)
            } catch (e: GetCredentialException) {

            }
        }
    }

    private fun handleCredential(
        credential: Credential,
        callback: SignInCallback
    ) {
        if (credential is CustomCredential &&
            credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
        ) {

            val googleIdTokenCredential =
                GoogleIdTokenCredential.createFrom(credential.data)

            if (googleIdTokenCredential.idToken.isNotEmpty()) {
                callback.onSuccessResult(
                    ThirdAuthResult(
                        googleIdTokenCredential.idToken,
                        ""
                    )
                )
            }else {
                callback.onFailure(Exception("Not Google ID Credential"))
            }

//            firebaseAuthWithGoogle(
//                googleIdTokenCredential.idToken,
//                callback
//            )
        } else {
            callback.onFailure(
                IllegalArgumentException("Not Google ID Credential")
            )
        }
    }

    private fun firebaseAuthWithGoogle(
        idToken: String,
        callback: SignInCallback
    ) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user == null) {
                        callback.onFailure(null)
                        return@addOnCompleteListener
                    }

                    // 🔥 关键：获取 Firebase ID Token
                    user.getIdToken(true)
                        .addOnSuccessListener { result ->
                            val firebaseIdToken = result.token

                            callback.onSuccessResult(
                                ThirdAuthResult(
                                    firebaseIdToken ?: "",
                                    ""
                                )
                            )
                        }
                        .addOnFailureListener {
                            callback.onFailure(it)
                        }
                } else {
                    callback.onFailure(task.exception)
                }
            }
    }

    fun signOut(onComplete: (() -> Unit)? = null) {
        auth.signOut()

        MainScope().launch {
            try {
                credentialManager.clearCredentialState(
                    ClearCredentialStateRequest()
                        )
                onComplete?.invoke()
            } catch (_: ClearCredentialException) {
            }
        }
    }

    fun getCurrentUser(): FirebaseUser? = auth.currentUser
}