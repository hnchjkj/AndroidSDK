package com.hncj.sdk.login.network

import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.login.network.service.RepositoryImpl
import com.hncj.sdk.login.network.service.Repository

internal object RequestClient {
    lateinit var repository: Repository

    fun init() {
        repository = RepositoryImpl(ConfigCache.serverDomain)
//        repository = RepositoryImpl("http://192.168.1.21:8191")

    }
}