package com.hncj.sdk.login.repository.impl

import com.hncj.sdk.login.api.SignInCallback
import com.linecorp.linesdk.LineApiResponseCode
import com.linecorp.linesdk.Scope
import com.linecorp.linesdk.auth.LineAuthenticationParams
import com.linecorp.linesdk.auth.LineLoginApi
import java.lang.Exception
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.hncj.sdk.login.api.ThirdAuthResult

internal class LineAuthImp(
    private val activity: ComponentActivity,
    private val channelId: String
) {

    private var callback: SignInCallback? = null

    private val launcher =
        activity.registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->

            val loginResult =
                LineLoginApi.getLoginResultFromIntent(result.data)

            when (loginResult.responseCode) {
                LineApiResponseCode.SUCCESS ->
                    callback?.onSuccessResult(
                        ThirdAuthResult(
                            loginResult.lineProfile?.userId,
                            ""
                        )

                    )

                LineApiResponseCode.CANCEL ->
                    callback?.onCancel()

                else ->
                    callback?.onFailure(Exception("Auth failed"))
            }

            callback = null
        }

    fun login(callback: SignInCallback) {
        this.callback = callback

        val params = LineAuthenticationParams.Builder()
            .scopes(listOf(Scope.PROFILE, Scope.OPENID_CONNECT))
            .build()

        val intent = LineLoginApi.getLoginIntent(
            activity,
            channelId,
            params
        )

        launcher.launch(intent)
    }
}
