package com.hncj.sdk.login.activity

import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.text.method.LinkMovementMethod
import android.util.Log
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.toColorInt
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.allen.library.shape.ShapeTextView
import com.chad.library.adapter.base.listener.OnItemClickListener
import com.gyf.immersionbar.ImmersionBar
import com.hncj.sdk.login.R
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.network.model.resp.VendorLoginConfig
import com.hncj.sdk.core.ui.activity.SimpleBrowserActivity
import com.hncj.sdk.core.utils.ToastUtils
import com.hncj.sdk.login.CJAuthSdk
import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.api.ThirdAuthResult
import com.hncj.sdk.login.listener.SdkLoginStateListener
import com.hncj.sdk.login.model.LoginViewModel
import com.hncj.sdk.login.network.model.resp.LoginResp
import com.hncj.sdk.login.repository.config.LoginType
import com.hncj.sdk.login.repository.config.toLoginButtonConfigs
import com.hncj.sdk.login.ui.dp
import me.gujun.android.span.span


class LoginActivity : AppCompatActivity() {

    private val mAdapter = LoginMethodAdapter()
    private val viewModel: LoginViewModel by lazy { LoginViewModel() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_login)

        ImmersionBar.with(this).statusBarDarkFont(false).init()
        viewModel.initLoading(this);
        val emailAddressEdit = findViewById<EditText>(R.id.emailAddressEdit)
        val emailCodeEdit = findViewById<EditText>(R.id.emailCodeEdit)
        val sendCodeBtn = findViewById<TextView>(R.id.sendEmail)
        val checkPrivacy = findViewById<CheckBox>(R.id.cb_privacy)

        findViewById<ShapeTextView>(R.id.btnLogin).apply {
            shapeBuilder
                ?.setShapeStrokeColor("#000000".toColorInt())
                ?.setShapeStrokeWidth(1.dp)
                ?.into(this)
            setOnClickListener {
                val account = emailAddressEdit.text.toString().trim()
                val password = emailCodeEdit.text.toString().trim()

                if (account.isEmpty()) {
                    ToastUtils.showShort(getString(R.string.email_login_error))
                    return@setOnClickListener
                }

                if (password.length < 6) {
                    ToastUtils.showShort(getString(R.string.email_code_login_error))
                    return@setOnClickListener
                }

                if (!checkPrivacy.isChecked) {
                    ToastUtils.showShort(getString(R.string.please_read_and_agree))
                    return@setOnClickListener
                }

                viewModel.login("email", account, password)

            }
        }

        sendCodeBtn.apply {
           setOnClickListener {
               val account = emailAddressEdit.text.toString().trim()

               if (account.isEmpty()) {
                   emailAddressEdit.error = getString(R.string.email_login_error)
                   return@setOnClickListener
               }

               viewModel.sendEmailCode(account)
           }
        }

        // 倒计时 UI
        viewModel.countDown.observe(this) { seconds ->
            if (seconds > 0) {
                sendCodeBtn.setText("${seconds}")
                sendCodeBtn.apply {
                    text = "${seconds}s"
                }
            } else {
                sendCodeBtn.apply {
                    text = getString(R.string.send_code)
                }
            }
        }

        // 是否可点击
        viewModel.canSendCode.observe(this) { canSend ->
            sendCodeBtn.isEnabled = canSend
        }

        emailAddressEdit.apply {
            inputType = InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            filters = arrayOf(InputFilter.LengthFilter(64))
            doAfterTextChanged {
                editable ->
                val email = editable?.toString()?.trim().orEmpty()
                if (email.length > 10) {
                    viewModel.isCanSendCode(true)
                }else {
                    viewModel.isCanSendCode(false)
                }
            }
        }

        emailCodeEdit.apply {
            inputType = InputType.TYPE_CLASS_PHONE
            filters = arrayOf(InputFilter.LengthFilter(6))
        }

        val loginCore = ConfigCache.getVendorLoginConfigList()

        val buttons = loginCore.toLoginButtonConfigs { loginType ->
            clickLogin(loginType, checkPrivacy.isChecked)
        }

        findViewById<RecyclerView>(R.id.loginButtonContainer).apply {
            // 通过「列数」适配横竖屏
            val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
            layoutManager = GridLayoutManager(this@LoginActivity, if(isLandscape) buttons.size else 3)
            adapter = mAdapter

            mAdapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
                val data=mAdapter.data[position]
//                viewModel.startCountDown()
                data.onClick.invoke(data.type)
            })
        }

        mAdapter.setList(buttons)

        findViewById<TextView>(R.id.tv_user_agree)?.apply {
            setOnClickListener {
                SimpleBrowserActivity.start(this@LoginActivity, ConfigCache.userAgreement,getString(R.string.user_agreement))
            }
        }

        findViewById<TextView>(R.id.tv_privacy_policy)?.apply {
            setOnClickListener {
                SimpleBrowserActivity.start(this@LoginActivity, ConfigCache.privacyAgreement, getString(R.string.privacy_policy))
            }
        }
    }

    fun clickLogin(type: LoginType, isCheck: Boolean) {
        if (!isCheck) {
            ToastUtils.showShort(getString(R.string.please_read_and_agree))
            return
        }
        CJAuthSdk.gameAuth(type, this)
    }
}