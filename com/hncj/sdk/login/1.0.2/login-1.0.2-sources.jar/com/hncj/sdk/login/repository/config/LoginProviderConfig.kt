package com.hncj.sdk.login.repository.config

import android.graphics.Color
import androidx.annotation.DrawableRes
import androidx.core.graphics.toColorInt
import com.hncj.sdk.login.R
import com.hncj.sdk.core.network.model.resp.VendorLoginConfig

//data class LoginProviderConfig(
//    val provider: LoginProvider,
//    val ui: ProviderUiConfig = ProviderUiConfig(),
//    val enabled: Boolean = true
//)
//
//data class LoginConfig(
//    val providers: List<LoginProviderConfig>
//)
//
//data class ProviderUiConfig(
//    val backgroundColor: Int? = null,
//    @DrawableRes val iconRes: Int? = null,
//    val text: String? = null,
//    val textColor: Int? = null,
//    val visible: Boolean = true
//)

enum class LoginType(val value: String) {
    GOOGLE("google"),
//    APPLE("apple"),
    FACEBOOK("facebook"),
    TWITTER("twitter"),
    LINE("line"),
    NAVER("naver"),
//    EMAIL("email"),
    GUEST("guest");

    companion object {
        fun from(value: String): LoginType? =
            values().firstOrNull { it.value.equals(value, ignoreCase = true) }
    }
}

data class LoginButtonConfig(
    val type: LoginType,
    val text: String,
    var iconRes: IconSource,
//    val bgColor: Int,
    val textColor: Int = Color.WHITE,
    val visible: Boolean = true,
    val onClick: (type:LoginType) -> Unit
)


fun List<VendorLoginConfig>.toLoginButtonConfigs(
    onClick: (LoginType) -> Unit
): List<LoginButtonConfig> {
    return this.mapNotNull { vendor ->
        val loginType = LoginType.from(vendor.loginType) ?: return@mapNotNull null

        LoginButtonConfig(
            type = loginType,
            text = vendor.loginTypeDesc,
            iconRes = vendor.resolveIcon(loginType),
//            bgColor = loginType.bgColor(),
            textColor = loginType.textColor(),
            visible = true,
            onClick = onClick
        )
    }
}

sealed class IconSource {
    data class Local(@DrawableRes val resId: Int) : IconSource()
    data class Remote(val url: String) : IconSource()
}

private fun VendorLoginConfig.resolveIcon(loginType: LoginType): IconSource {
    return if (loginTypeIcon.isNotBlank()) {
        IconSource.Remote(loginTypeIcon)
    } else {
        IconSource.Local(loginType.iconRes())
    }
}

fun LoginType.iconRes(): Int = when (this) {
    LoginType.GOOGLE -> R.drawable.ic_google
    LoginType.FACEBOOK -> R.drawable.ic_facebook
    LoginType.TWITTER -> R.drawable.ic_twitter
    LoginType.LINE -> R.drawable.ic_line
    LoginType.NAVER -> R.drawable.ic_never
//    LoginType.EMAIL -> R.drawable.ic
    LoginType.GUEST -> R.drawable.ic_guess
//    LoginType.APPLE -> TODO()
//    LoginType.NAVER -> TODO()
//    LoginType.EMAIL -> TODO()
}

fun LoginType.textColor(): Int = when (this) {
    LoginType.GOOGLE -> "#1578F2".toColorInt()
    else -> "#1578F2".toColorInt()
}


