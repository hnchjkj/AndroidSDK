package com.hncj.sdk.login.network

/**
 * SDK 配置模型（只存内存）
 */
data class AppConfig(
    val baseUrl: String,
    val appKey: String,
    val appSecret: String
)


