package com.hncj.sdk.login.network.service

import com.hncj.sdk.login.network.ApiResponse
import com.hncj.sdk.login.network.model.BaseResponse
import com.hncj.sdk.login.network.model.resp.LoginResp
import retrofit2.http.Body
import retrofit2.http.FieldMap
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

internal interface ApiService {
    /**
     * 发送验证码
     * email
     * */
    @FormUrlEncoded
    @POST("/user/login/sendLoginCodeEmail")
    suspend fun sendLoginCodeEmail(@FieldMap params: HashMap<String, String>): BaseResponse<Any>

    /**
     * 聚合登录
     * loginMode 登录方式
     * loginCode 通用授权码/账号
     * loginKey  通用密钥/密码
     * */
    @FormUrlEncoded
    @POST("/user/login/aggregation")
    suspend fun aggregationLogin(@FieldMap params: HashMap<String, String>): BaseResponse<LoginResp>

    /**
     * 登出
     * */
    @FormUrlEncoded
    @POST("/user/login/logout")
    suspend fun loginOut(@FieldMap params: HashMap<String, String>): BaseResponse<Any>

    /**
     * 注销
     * */
    @FormUrlEncoded
    @POST("/login/deactivateAccount")
    suspend fun deactivateAccount(@FieldMap params: HashMap<String, String>): BaseResponse<Any>


    @FormUrlEncoded
    @POST("/user/login/queryLoginTypeAble")
    suspend fun queryLoginTypeAble(@FieldMap params: HashMap<String, String>): BaseResponse<LoginResp>
}