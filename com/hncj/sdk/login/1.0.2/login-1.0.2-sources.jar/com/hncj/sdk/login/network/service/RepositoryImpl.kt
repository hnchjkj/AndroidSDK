package com.hncj.sdk.login.network.service

import androidx.annotation.RestrictTo
import com.hncj.sdk.login.network.NetworkFactory
import com.hncj.sdk.login.network.Result
import com.hncj.sdk.login.network.ResultTransformer
import com.hncj.sdk.login.network.model.resp.LoginResp
import retrofit2.create

@RestrictTo(RestrictTo.Scope.LIBRARY)
internal class RepositoryImpl(url: String) : Repository {

    private val service: ApiService by lazy { NetworkFactory.createRetrofit(url).create() }

    override suspend fun queryLoginTypeAble(): Result<LoginResp> {
        return ResultTransformer.asResult(
            networkCall = {
                val params = hashMapOf<String, String>().apply {

                }
                service.queryLoginTypeAble(params)
            },
            successCall = {
                // 请求成功回调，这里可以做参数保存
            },
            transformer = { it }
        )
    }

    override suspend fun sendLoginCodeEmail(emailAddress: String): Result<Any> {
        return ResultTransformer.asResult(
            networkCall = {
                val params = hashMapOf<String, String>().apply {
                    put("email" , emailAddress)
                }
                service.sendLoginCodeEmail(params)
            },
            successCall = {
                // 请求成功回调，这里可以做参数保存
            },
        )
    }

    override suspend fun aggregationLogin(loginMode: String, loginCode: String, loginKey: String): Result<LoginResp> {
        return ResultTransformer.asResult(
            networkCall = {
                val params = hashMapOf<String, String>().apply {
                    put("loginMode" , loginMode)
                    put("loginCode" , loginCode)
                    put("loginKey" , loginKey)
                }
                service.aggregationLogin(params)
            },
            successCall = {
                // 请求成功回调，这里可以做参数保存
                it.data.save()
            },
            transformer = { it }
        )
    }

    override suspend fun loginOut(): Result<Any> {
        return ResultTransformer.asResult(
            networkCall = {
                val params = hashMapOf<String, String>().apply {

                }
                service.loginOut(params)
            },
            successCall = {
                // 请求成功回调，这里可以做参数保存
            },
        )
    }

    override suspend fun deactivateAccount(): Result<Any> {
        return ResultTransformer.asResult(
            networkCall = {
                val params = hashMapOf<String, String>().apply {

                }
                service.deactivateAccount(params)
            },
            successCall = {
                // 请求成功回调，这里可以做参数保存
            },
        )
    }
}