package com.hncj.sdk.login.api

data class AuthUser(
    val uid: String,
    val email: String?,
    val phone: String?,
    val isAnonymous: Boolean
)
