package com.hncj.sdk.login.network

data class BusinessException(
    val errorCode: Int = 0,
    val errorMessage: String? = null
) : Exception(errorMessage)