package com.hncj.sdk.login.network

internal object AppConfigHolder {
    private var config: AppConfig? = null

    fun init(appConfig: AppConfig) {
        if (config != null) return
        config = appConfig
    }

    fun get(): AppConfig {
        return config
            ?: throw IllegalStateException(
                "AppConfig is not initialized. Call CJCoreSdk.init() first."
            )
    }
}