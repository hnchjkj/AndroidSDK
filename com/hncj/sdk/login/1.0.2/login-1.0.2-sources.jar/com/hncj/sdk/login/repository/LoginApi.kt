package com.hncj.sdk.login.repository

import com.hncj.sdk.login.network.ApiResponse
import com.hncj.sdk.login.result.LoginReult
import retrofit2.http.Body
import retrofit2.http.FieldMap
import retrofit2.http.POST


interface LoginApi {


}
