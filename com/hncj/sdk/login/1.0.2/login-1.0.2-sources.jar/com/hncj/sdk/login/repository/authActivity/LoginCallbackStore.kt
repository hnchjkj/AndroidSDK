package com.hncj.sdk.login.repository.authActivity

import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.api.ThirdAuthResult
import kotlin.collections.set

internal object LoginCallbackStore {

    private val callbacks = mutableMapOf<String, SignInCallback>()

    fun put(id: String, callback: SignInCallback) {
        callbacks[id] = callback
    }

    fun success(id: String?, authInfo: ThirdAuthResult) {
        callbacks.remove(id)?.onSuccessResult(authInfo)
    }

    fun cancel(id: String?) {
        callbacks.remove(id)?.onCancel()
    }

    fun failure(id: String?, e: Exception) {
        callbacks.remove(id)?.onFailure(e)
    }

    fun take(requestId: String): SignInCallback? {
        return callbacks.remove(requestId) // ⭐ 用完即删
    }
}
