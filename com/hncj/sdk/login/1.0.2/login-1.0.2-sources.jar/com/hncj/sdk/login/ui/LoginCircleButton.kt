package com.hncj.sdk.login.ui
import android.content.Context
import android.content.res.Resources
import androidx.annotation.DrawableRes
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.Gravity
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.hncj.sdk.login.R
import com.hncj.sdk.login.repository.config.LoginButtonConfig

class LoginCircleButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {


    private val icon: ImageView
    private val text: TextView


    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        inflate(context, R.layout.view_login_circle_button, this)
        icon = findViewById(R.id.ivIcon)
        text = findViewById(R.id.tvText)
    }


    fun bind(config: LoginButtonConfig) {
        visibility = if (config.visible) VISIBLE else GONE
//        icon.setImageResource(config.iconRes)
        text.text = config.text
        text.setTextColor(config.textColor)
//        background = GradientDrawable().apply {
//            shape = GradientDrawable.OVAL
//            setColor(config.bgColor)
//        }
        setOnClickListener { config.onClick(config.type) }
    }
}


val Int.dp: Int
    get() = (this * Resources.getSystem().displayMetrics.density).toInt()