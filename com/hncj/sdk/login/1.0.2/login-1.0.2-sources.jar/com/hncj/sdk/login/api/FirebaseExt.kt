package com.hncj.sdk.login.api

import com.google.firebase.auth.FirebaseUser

fun FirebaseUser.toAuthUser(): AuthUser =
    AuthUser(
        uid = uid,
        email = email,
        phone = phoneNumber,
        isAnonymous = isAnonymous
    )
