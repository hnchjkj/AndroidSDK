package com.hncj.sdk.login.repository


import android.content.Context
import android.content.Intent
import com.hncj.sdk.login.R
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.utils.ToastUtils
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.login.activity.LoadingDialog
import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.activity.LoginActivity
import com.hncj.sdk.login.api.ThirdAuthResult
import com.hncj.sdk.login.listener.SdkLoginStateListener
import com.hncj.sdk.login.network.RequestClient
import com.hncj.sdk.login.network.Result
import com.hncj.sdk.login.provider.LoginCallbackHolder
import com.hncj.sdk.login.repository.authActivity.FaceBookAuthActivity
import com.hncj.sdk.login.repository.authActivity.LineAuthActivity
import com.hncj.sdk.login.repository.authActivity.LoginCallbackStore
import com.hncj.sdk.login.repository.config.LoginType
import com.hncj.sdk.login.repository.impl.GoogleAuthProviderImp
import com.hncj.sdk.login.repository.impl.NaverAuthSDK
import com.hncj.sdk.login.repository.impl.SignInAnonymouslyImp
import com.hncj.sdk.login.repository.impl.TwitterAuthImp
import com.hncj.sdk.login.utils.LOG
import com.twitter.sdk.android.core.TwitterAuthConfig
import kotlinx.coroutines.launch
import java.util.UUID


internal class LoginRepository {

    private lateinit var googleAuthProviderImp: GoogleAuthProviderImp
    private lateinit var signInAnonymouslyImp: SignInAnonymouslyImp
    private lateinit var twitterAuthImp: TwitterAuthImp

    private lateinit var loading: LoadingDialog
    private lateinit var mContext: Context

    fun init(sdkLoginStateListener: SdkLoginStateListener){
        LoginCallbackHolder.listener = sdkLoginStateListener
    }

    fun initContext( context: Context){
        mContext = context
        loading = LoadingDialog(mContext)
    }

    /**
     * 谷歌登录
     * */
    fun signInGoogle(type : LoginType,serverClientId: String) {
        googleAuthProviderImp = GoogleAuthProviderImp(
            context = mContext,
            serverClientId = serverClientId
        )

        googleAuthProviderImp.signIn(
            object : SignInCallback{
                override fun onSuccessResult(result: ThirdAuthResult?) {
                    login(type.value,result?.accessToken!!, "")
                }

                override fun onFailure(e: Exception?) {
                    ToastUtils.showShort(mContext.getString(R.string.auth_failed))
                }

            }
        );
    }

    /**
     * 游客登录/匿名登录
     * */
    fun loginAnonymously(type : LoginType) {
        login(type.value,ConfigCache.uuid, "")
    }

    /**
     * 邮箱登录
     * */
    fun emailCodeLogin(emailAddress: String, emailCode: String) {
        login("email",emailAddress, emailCode)
    }

    /**
     * twitter 登录
     * */
    fun loginTwitter(type : LoginType,config :TwitterAuthConfig) {
        twitterAuthImp = TwitterAuthImp(mContext, config)
        twitterAuthImp.login(
            object : SignInCallback{
                override fun onSuccessResult(result: ThirdAuthResult?) {
                    login(type.value, result?.accessToken!!,  result.secret!!)
                }

                override fun onFailure(e: Exception?) {
                    ToastUtils.showShort(mContext.getString(R.string.auth_failed))
                }
            }
        )
    }

    /**
     * facebook 登录
     * */
    fun loginFacebook(type : LoginType) {
        val requestId = UUID.randomUUID().toString()
        LoginCallbackStore.put(requestId, object : SignInCallback{
            override fun onSuccessResult(result: ThirdAuthResult?) {
                login(type.value, result?.accessToken!!,  "")
            }

            override fun onFailure(e: Exception?) {
                ToastUtils.showShort(mContext.getString(R.string.auth_failed))
            }
        })

        val intent = Intent(mContext, FaceBookAuthActivity::class.java).apply {
            putExtra(LineAuthActivity.EXTRA_REQUEST_ID, requestId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        mContext.startActivity(intent)
    }

    /**
     * line 登录
     * */
    fun loginLine(type: LoginType,key: String) {
        val requestId = UUID.randomUUID().toString()
        LoginCallbackStore.put(requestId, object : SignInCallback{
            override fun onSuccessResult(result: ThirdAuthResult?) {
                login(type.value, result?.accessToken!!,  "")
            }

            override fun onFailure(e: Exception?) {
                ToastUtils.showShort(mContext.getString(R.string.auth_failed))
            }
        })

        val intent = Intent(mContext, LineAuthActivity::class.java).apply {
            putExtra(LineAuthActivity.EXTRA_CHANNEL_ID, key)
            putExtra(LineAuthActivity.EXTRA_REQUEST_ID, requestId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        mContext.startActivity(intent)
    }

    /**
     * naver 登录
     * */
    fun loginNaver(type: LoginType, serverClientId: String, serverSecret: String, appName: String) {
        NaverAuthSDK.login(
            context = mContext,
            clientId = serverClientId,
            clientSecret = serverSecret,
            appName = appName,
            callback = object : SignInCallback{
                override fun onSuccessResult(result: ThirdAuthResult?) {
                    login(type.value, result?.accessToken!!,  result.secret!!)
                }

                override fun onFailure(e: Exception?) {
                    ToastUtils.showShort(mContext.getString(R.string.auth_failed))
                }
            }
        )

    }

    fun showLoginActivity(mSdkLoginStateListener: SdkLoginStateListener?) {
        LoginCallbackHolder.listener = mSdkLoginStateListener
        val intent = Intent(Utils.app, LoginActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        Utils.app.startActivity(intent)
    }

    fun loginOut(mSdkLoginStateListener: SdkLoginStateListener?) {
        LoginCallbackHolder.listener = mSdkLoginStateListener
        Utils.mCoroutineScope.launch {
            when (val result = RequestClient.repository.loginOut()) {
                is Result.Success -> {
                    LOG.i(LOG.TAG_HTTP, "queryVendorConfig -> success, ${ConfigCache.token}")
                    ConfigCache.token = ""
                    LoginCallbackHolder.listener?.onLoginOutSuccess()
                }

                is Result.Error -> {
                    LOG.e(LOG.TAG_HTTP, "queryVendorConfig -> error, ${result.error.errorMessage}")
                    ToastUtils.showShort("${result.error.errorMessage}")
                    LoginCallbackHolder.listener?.onLoginOutOnFailed(result.error.errorCode, result.error.errorMessage)
                }

                else -> {}
            }
        }
    }

    fun deactivateAccount(mSdkLoginStateListener: SdkLoginStateListener?) {
        LoginCallbackHolder.listener = mSdkLoginStateListener
        Utils.mCoroutineScope.launch {
            when (val result = RequestClient.repository.deactivateAccount()) {
                is Result.Success -> {
                    LOG.i(LOG.TAG_HTTP, "queryVendorConfig -> success, ${ConfigCache.token}")
                    ConfigCache.token = ""
                    LoginCallbackHolder.listener?.onLoginOutSuccess()
                }

                is Result.Error -> {
                    LOG.e(LOG.TAG_HTTP, "queryVendorConfig -> error, ${result.error.errorMessage}")
                    LoginCallbackHolder.listener?.onLoginOutOnFailed(result.error.errorCode, result.error.errorMessage)
                }

                else -> {
                    LoginCallbackHolder.listener?.onLoginOutOnFailed(-1, "")
                }
            }
        }
    }

    // 聚合登录
    fun login(loginMode: String, loginCode: String, loginKey: String) {
        loading.show()
        Utils.mCoroutineScope.launch {
            when (val result = RequestClient.repository.aggregationLogin(loginMode,loginCode,loginKey)) {
                is Result.Success -> {
                    LOG.i(LOG.TAG_HTTP, "queryVendorConfig -> success, ${ConfigCache.token}")
                    LoginCallbackHolder.listener?.onLoginSuccess(result.data)
                    loading.dismiss()
                    // 登录成功后关闭 LoginActivity
                    if (mContext is LoginActivity) {
                        (mContext as LoginActivity).finish()
                    }
                }

                is Result.Error -> {
                    LOG.e(LOG.TAG_HTTP, "queryVendorConfig -> error, ${result.error.errorMessage}")
                    LoginCallbackHolder.listener?.onLoginFailed(result.error.errorCode, result.error.errorMessage)
                    loading.dismiss()
                }

                else -> {
                    loading.dismiss()
                }
            }
        }
    }
}