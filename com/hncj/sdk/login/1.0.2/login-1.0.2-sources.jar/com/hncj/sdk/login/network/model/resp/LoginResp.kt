package com.hncj.sdk.login.network.model.resp

import androidx.annotation.Keep
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.login.api.ThirdAuthResult

@Keep
data class LoginResp (
    val userId: Any,
    val nickname: String,
    val avatar: String,
    val token: String,
    val loginMode: String
){
    fun save() {
        ConfigCache.token = token
    }
}
