package com.hncj.sdk.login.network.converter

import com.google.gson.TypeAdapter
import com.hncj.sdk.login.ext.gson
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.Buffer
import retrofit2.Converter
import java.io.OutputStreamWriter

internal class RequestBodyConverter<T>(private val adapter: TypeAdapter<T>) :
    Converter<T, RequestBody> {

    companion object {
        private val mediaType = "application/json; charset=UTF-8".toMediaType()
    }

    override fun convert(value: T): RequestBody {
        val buffer = Buffer()
        val outputStreamWriter = OutputStreamWriter(buffer.outputStream(), Charsets.UTF_8)
        val jsonWriter = gson.newJsonWriter(outputStreamWriter)
        adapter.write(jsonWriter, value)
        jsonWriter.close()
        return buffer.readByteString().toRequestBody(mediaType)
    }
}