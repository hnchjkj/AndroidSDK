package com.hncj.sdk.login.repository.impl
import com.google.firebase.auth.FirebaseAuth
import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.api.ThirdAuthResult

/**
 * 游客登录
 * */
internal class SignInAnonymouslyImp  {
    private var auth = FirebaseAuth.getInstance()

    fun login(callback: SignInCallback) {
        auth.signInAnonymously().addOnCompleteListener { task ->
            if(task.isSuccessful) {
                callback.onSuccessResult(ThirdAuthResult(
                    auth.currentUser!!.uid,
                    ""
                ))
            }else {
                callback.onFailure(task.exception)
            }
        }
    }
}