package com.hncj.sdk.login.network.service

import com.hncj.sdk.login.network.Result
import com.hncj.sdk.login.network.model.resp.LoginResp

interface Repository {

    suspend fun aggregationLogin(loginMode: String, loginCode: String, loginKey: String): Result<LoginResp>
    suspend fun queryLoginTypeAble(): Result<LoginResp>
    suspend fun sendLoginCodeEmail(emailAddress: String): Result<Any>
    suspend fun loginOut(): Result<Any>
    suspend fun deactivateAccount(): Result<Any>
}