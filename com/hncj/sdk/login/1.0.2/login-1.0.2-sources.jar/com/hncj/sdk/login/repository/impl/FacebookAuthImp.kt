package com.hncj.sdk.login.repository.impl

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.facebook.CallbackManager
import com.facebook.FacebookSdk
import com.facebook.FacebookCallback
import com.facebook.login.LoginManager
import com.facebook.FacebookException
import com.facebook.login.LoginResult
import com.google.firebase.auth.OAuthProvider
import com.hncj.sdk.login.api.SignInCallback
import com.facebook.AccessToken
import com.google.firebase.Firebase
import com.google.firebase.auth.FacebookAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.hncj.sdk.login.api.ThirdAuthResult

internal class FacebookAuthImp(
    private val context: Context
) {

    private val callbackManager: CallbackManager =
        CallbackManager.Factory.create()

    private val firebaseAuth: FirebaseAuth =
        FirebaseAuth.getInstance()

    init {
        FacebookSdk.sdkInitialize(context.applicationContext)
    }

    fun signInWithProvider(provider: OAuthProvider.Builder,callback: SignInCallback) {

        firebaseAuth
            .startActivityForSignInWithProvider(context as Activity, provider.build())
            .addOnSuccessListener {
                    authResult ->
                val user = authResult.user
                // User is signed in.
                // IdP data available in
                // authResult.getAdditionalUserInfo().getProfile().
                // The OAuth access token can also be retrieved:
                // ((OAuthCredential)authResult.getCredential()).getAccessToken().
                // The OAuth secret can be retrieved by calling:
                // ((OAuthCredential)authResult.getCredential()).getSecret().
                callback.onSuccessResult(ThirdAuthResult(
                    user?.uid ?: "",
                    ""
                ))
            }
            .addOnFailureListener {
                // Handle failure.
                callback.onFailure(it)
            }
        // [END auth_oidc_provider_signin]
    }

    /**
     * Facebook 登录方法
     */
    fun login(callback: SignInCallback) {

        LoginManager.getInstance().registerCallback(
            callbackManager,
            object : FacebookCallback<LoginResult> {

                override fun onSuccess(result: LoginResult) {
                    handleFacebookAccessToken(result.accessToken, callback)
                }

                override fun onCancel() {
                    callback.onFailure(Exception("cancel"))
                }

                override fun onError(error: FacebookException) {
                    callback.onFailure(Exception(error.message))
                }
            }
        )

        LoginManager.getInstance().logInWithReadPermissions(
            context as Activity,
            listOf("email", "public_profile")
        )

    }

    private fun handleFacebookAccessToken(token: AccessToken,callback: SignInCallback) {

        val credential = FacebookAuthProvider.getCredential(token.token)
        firebaseAuth
            .signInWithCredential(credential)
            .addOnSuccessListener {
                    authResult ->
                val user = authResult.user
                // User is signed in.
                // IdP data available in
                // authResult.getAdditionalUserInfo().getProfile().
                // The OAuth access token can also be retrieved:
                // ((OAuthCredential)authResult.getCredential()).getAccessToken().
                // The OAuth secret can be retrieved by calling:
                // ((OAuthCredential)authResult.getCredential()).getSecret().
                callback.onSuccessResult(ThirdAuthResult(
                    user?.uid ?: "",
                    ""
                ))
            }
            .addOnFailureListener {
                // Handle failure.
                callback.onFailure(it)
            }
    }

    fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        callbackManager.onActivityResult(requestCode, resultCode, data)
    }
}