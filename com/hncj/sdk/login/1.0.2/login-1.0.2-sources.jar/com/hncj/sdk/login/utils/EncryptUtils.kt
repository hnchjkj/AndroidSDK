package com.hncj.sdk.login.utils

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object EncryptUtils {
    fun encrypt(
        url: String,
        body: String,
        appSecret: String
    ): String {
        if (url.isEmpty()) {
            LOG.e(LOG.TAG, "encrypt error, url is empty")
            return ""
        }
        if (body.isEmpty()) {
            LOG.e(LOG.TAG, "encrypt error, body is empty")
            return ""
        }
        if (appSecret.isEmpty()) {
            LOG.e(LOG.TAG, "encrypt error, secret is empty")
            return ""
        }
        val data = url + body
        val mac = Mac.getInstance("HmacSHA256")
        val secretKey = SecretKeySpec(
            appSecret.toByteArray(Charsets.UTF_8),
            "HmacSHA256"
        )
        mac.init(secretKey)
        val rawHmac = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        return rawHmac.toHexLower()
    }

    private fun ByteArray.toHexLower(): String =
        joinToString("") { "%02x".format(it) }
}