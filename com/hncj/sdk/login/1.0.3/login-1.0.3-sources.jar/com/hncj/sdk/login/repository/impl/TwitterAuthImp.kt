package com.hncj.sdk.login.repository.impl

import android.app.Activity
import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.OAuthCredential
import com.google.firebase.auth.OAuthProvider
import com.hncj.sdk.login.R
import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.api.ThirdAuthResult
import com.twitter.sdk.android.core.TwitterAuthConfig
import com.twitter.sdk.android.core.identity.TwitterAuthClient

internal class TwitterAuthImp(
    private val context: Context,
    private val config: TwitterAuthConfig
) {
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
    private lateinit var twitterAuthClient: TwitterAuthClient

    fun signInWithProvider(provider: OAuthProvider.Builder,callback: SignInCallback) {
        // [START auth_oidc_provider_signin]
        firebaseAuth
            .startActivityForSignInWithProvider(context as Activity, provider.build())
            .addOnSuccessListener {
                authResult ->
                val user = authResult.user
                // User is signed in.
                // IdP data available in
                // authResult.getAdditionalUserInfo().getProfile().
                // The OAuth access token can also be retrieved:
                // ((OAuthCredential)authResult.getCredential()).getAccessToken().
                // The OAuth secret can be retrieved by calling:
                // ((OAuthCredential)authResult.getCredential()).getSecret().

                val credential = authResult.credential

                if (credential is OAuthCredential) {
                    val idToken = credential.idToken
                    val accessToken = credential.accessToken
                    val secret = credential.secret
                    callback.onSuccessResult(ThirdAuthResult(
                        accessToken,
                        secret
                    ))
                }

            }
            .addOnFailureListener {
                authResult ->
                // Handle failure.
                callback.onFailure(Exception(authResult.message))
            }
            .addOnCanceledListener {
                callback.onCancel()
            }
         
    }

    /**
     * Twitter 登录方法
     */
    fun login(callback: SignInCallback) {
        val provider = OAuthProvider.newBuilder("twitter.com")
        provider.addCustomParameter("lang", "fr")
        signInWithProvider(provider, callback)
    }

}