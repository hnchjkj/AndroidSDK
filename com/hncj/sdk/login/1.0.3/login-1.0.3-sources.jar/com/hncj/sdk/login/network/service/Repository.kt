package com.hncj.sdk.login.network.service

import com.hncj.sdk.login.network.Result
import com.hncj.sdk.login.network.model.resp.AccountManagementResp
import com.hncj.sdk.login.network.model.resp.BindThirdPartyResp
import com.hncj.sdk.login.network.model.resp.LoginResp

internal interface Repository {
    suspend fun aggregationLogin(
        loginMode: String,
        loginCode: String,
        loginKey: String
    ): Result<LoginResp>

    suspend fun queryLoginTypeAble(): Result<LoginResp>
    suspend fun sendLoginCodeEmail(emailAddress: String): Result<Any>
    suspend fun loginOut(): Result<Any>
    suspend fun deactivateAccount(): Result<Any>

    suspend fun queryThirdBindList(): Result<AccountManagementResp>
    suspend fun bindThirdParty(
        loginMode: String,
        loginCode: String,
        loginKey: String
    ): Result<BindThirdPartyResp>

    suspend fun unbindThirdParty(loginMode: String): Result<Any>
    suspend fun replaceThirdPartyBind(
        loginMode: String,
        loginCode: String,
        loginKey: String
    ): Result<Any>
}