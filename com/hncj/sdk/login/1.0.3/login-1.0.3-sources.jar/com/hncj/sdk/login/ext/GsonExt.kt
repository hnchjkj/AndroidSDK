package com.hncj.sdk.login.ext

import com.google.gson.Gson
import com.google.gson.GsonBuilder

val gson: Gson = GsonBuilder().disableInnerClassSerialization()
    .setDateFormat("yyyy-MM-dd HH:mm:ss")
    .setLenient()
    .create()