package com.hncj.sdk.login.provider

import com.hncj.sdk.login.listener.SdkLoginStateListener

internal object LoginCallbackHolder {
    var listener: SdkLoginStateListener? = null
}