package com.hncj.sdk.login.network.model.resp

import androidx.annotation.Keep
import java.io.Serializable

/**
 * date：2026-02-04 13:23
 * desc：
 */
@Keep
class AccountManagementResp : ArrayList<AccountManagementItem>(), Serializable

@Keep
data class AccountManagementItem(
    val isBind: Boolean,
    val loginType: String,
    val loginTypeDesc: String,
    val loginTypeIcon: String,
    val thirdPartyNickName: String
) : Serializable