package com.hncj.sdk.login.activity

import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.hncj.sdk.login.R
import com.hncj.sdk.core.network.model.resp.VendorLoginConfig
import com.hncj.sdk.login.repository.config.IconSource
import com.hncj.sdk.login.repository.config.LoginButtonConfig
import com.hncj.sdk.login.repository.config.iconRes

internal class LoginMethodAdapter :
    BaseQuickAdapter<LoginButtonConfig, BaseViewHolder>(R.layout.view_login_circle_button) {
    override fun convert(
        holder: BaseViewHolder,
        item: LoginButtonConfig
    ) {
        val ivIcon = holder.getViewOrNull<ImageView>(R.id.ivIcon)
        val tvText = holder.getViewOrNull<TextView>(R.id.tvText)

        // 关键：统一处理 icon
        when (val icon = item.iconRes) {
            is IconSource.Local -> {
                ivIcon?.setImageResource(icon.resId)
            }
            is IconSource.Remote -> {
                Glide.with(ivIcon!!)
                    .load(icon.url)
                    .placeholder(item.type.iconRes())
                    .error(item.type.iconRes()) // 网络失败兜底
                    .into(ivIcon)
            }
        }
//        ivIcon?.setImageResource(item.iconRes)
        tvText?.text = item.text
    }
}
