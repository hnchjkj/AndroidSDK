package com.hncj.sdk.login.ext

fun currentSeconds(): Long {
    return System.currentTimeMillis() / 1000
}