package com.hncj.sdk.login.repository.authActivity
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.FragmentActivity
import com.hncj.sdk.login.R
import com.hncj.sdk.login.api.ThirdAuthResult
import com.linecorp.linesdk.LineApiResponseCode
import com.linecorp.linesdk.Scope
import com.linecorp.linesdk.auth.LineAuthenticationParams
import com.linecorp.linesdk.auth.LineLoginApi

internal class LineAuthActivity : FragmentActivity() {

    companion object {
        const val EXTRA_CHANNEL_ID = "channel_id"
        const val EXTRA_REQUEST_ID = "request_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val channelId = intent.getStringExtra(EXTRA_CHANNEL_ID) ?: run {
            finish()
            return
        }

        val launcher =
            registerForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { result ->

                val loginResult =
                    LineLoginApi.getLoginResultFromIntent(result.data)

                when (loginResult.responseCode) {
                    LineApiResponseCode.SUCCESS -> {
                        LoginCallbackStore.success(
                            intent.getStringExtra(EXTRA_REQUEST_ID),
                            ThirdAuthResult(
                                loginResult.lineIdToken?.rawString,
                                ""
                            )
                        )
                    }

                    LineApiResponseCode.CANCEL ->
                        LoginCallbackStore.cancel(
                            intent.getStringExtra(EXTRA_REQUEST_ID)
                        )

                    else ->
                        LoginCallbackStore.failure(
                            intent.getStringExtra(EXTRA_REQUEST_ID),
                            Exception(getString(R.string.auth_failed))
                        )

                }

                finish()
            }

        val params = LineAuthenticationParams.Builder()
            .scopes(listOf(Scope.PROFILE, Scope.OPENID_CONNECT))
            .build()

        val intent = LineLoginApi.getLoginIntent(
            this,
            channelId,
            params
        )

        launcher.launch(intent)
    }
}
