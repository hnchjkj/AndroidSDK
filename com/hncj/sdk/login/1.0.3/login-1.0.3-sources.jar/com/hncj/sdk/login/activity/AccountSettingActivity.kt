package com.hncj.sdk.login.activity

import android.content.Context
import android.content.Intent
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.hncj.sdk.core.ext.onThrottleClick
import com.hncj.sdk.core.ext.toast
import com.hncj.sdk.core.ui.BaseActivity
import com.hncj.sdk.core.utils.LoadingDialogHelper
import com.hncj.sdk.login.R
import com.hncj.sdk.login.databinding.ActivityAccountSettingBinding
import com.hncj.sdk.login.network.RequestClient
import com.hncj.sdk.login.network.Result
import com.hncj.sdk.login.network.model.resp.AccountManagementItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal class AccountSettingActivity : BaseActivity<ActivityAccountSettingBinding>() {

    companion object {
        fun start(context: Context, data: AccountManagementItem) {
            context.startActivity(
                Intent(context, AccountSettingActivity::class.java).apply {
                    putExtra("data", data)
                }
            )
        }
    }

    override fun initViews() {
        mDataBinding.apply {
            val data = intent.getSerializableExtra("data") as AccountManagementItem?
            data?.apply {
                Glide.with(this@AccountSettingActivity)
                    .load(loginTypeIcon)
                    .into(mustIconIv)
                mustContentTv.text =
                    "${getString(R.string.tips_account_setting_start)} ${loginTypeDesc} ${
                        getString(R.string.tips_account_setting_end)
                    }"
            }

            mustBackAny.onThrottleClick {
                finish()
            }

            mustUnlinkAny.onThrottleClick {
                val loginType = data?.loginType.orEmpty()
                if (loginType.isEmpty()) {
                    return@onThrottleClick
                }
                val loadingDialog =
                    LoadingDialogHelper.getLoadingDialog(this@AccountSettingActivity)
                loadingDialog.dismiss()
                lifecycleScope.launch {
                    when (val result = RequestClient.repository.unbindThirdParty(loginType)) {
                        is Result.Success -> {
                            withContext(Dispatchers.Main) {
                                loadingDialog.dismiss()
                            }
                            toast(getString(R.string.toast_unbind_success))
                            finish()
                        }

                        is Result.Error -> {
                            withContext(Dispatchers.Main) {
                                loadingDialog.dismiss()
                            }
                            toast(getString(R.string.toast_unbind_failed))
                        }

                        else -> {}
                    }
                }
            }
        }
    }

    override fun statusBarDarkFont(): Boolean {
        return true
    }

    override fun initDataObserver() {}

    override fun getLayoutId(): Int {
        return R.layout.activity_account_setting
    }
}