package com.hncj.sdk.login.api
import android.content.Context
data class AuthConfig(
    val context: Context,
    val googleClientId: String
)
