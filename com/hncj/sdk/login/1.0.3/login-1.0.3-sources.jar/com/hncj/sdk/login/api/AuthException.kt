package com.hncj.sdk.login.api

class AuthException(
    override val message: String?
) : Exception(message)