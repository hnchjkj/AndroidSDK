package com.hncj.sdk.login.model

import android.content.Context
import android.os.CountDownTimer
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.utils.LOG
import com.hncj.sdk.core.utils.ToastUtils
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.login.activity.LoadingDialog
import com.hncj.sdk.login.network.RequestClient
import com.hncj.sdk.login.network.Result
import com.hncj.sdk.login.provider.LoginCallbackHolder
import kotlinx.coroutines.launch

internal class LoginViewModel : ViewModel() {

    private lateinit var loading: LoadingDialog

    fun initLoading(context: Context) {
        loading = LoadingDialog(context)
    }

    // 发送邮件验证码
    fun sendEmailCode(emailAddress: String) {
        if (_canSendCode.value == false) return
        viewModelScope.launch {
            when (val result = RequestClient.repository.sendLoginCodeEmail(emailAddress)) {
                is Result.Success -> {
                    LOG.i(LOG.LOGIN_TAG_HTTP, "queryVendorConfig -> success")
                    startCountDown(59)
                }

                is Result.Error -> {
                    LOG.e(
                        LOG.LOGIN_TAG_HTTP,
                        "queryVendorConfig -> error, ${result.error.errorMessage}"
                    )
                    ToastUtils.showShort("${result.error.errorMessage}")
                }

                else -> {}
            }
        }
    }

    // 聚合登录
    fun login(loginMode: String, loginCode: String, loginKey: String) {
        loading.show()
        Utils.mCoroutineScope.launch {
            when (val result =
                RequestClient.repository.aggregationLogin(loginMode, loginCode, loginKey)) {
                is Result.Success -> {
                    LOG.i(LOG.LOGIN_TAG_HTTP, "queryVendorConfig -> success, ${ConfigCache.token}")
                    LoginCallbackHolder.listener?.onLoginSuccess(result.data)
                    loading.dismiss()
                }

                is Result.Error -> {
                    LOG.e(
                        LOG.LOGIN_TAG_HTTP,
                        "queryVendorConfig -> error, ${result.error.errorMessage}"
                    )
                    ToastUtils.showShort("${result.error.errorMessage}")
                    LoginCallbackHolder.listener?.onLoginFailed(
                        result.error.errorCode,
                        result.error.errorMessage
                    )
                    loading.dismiss()
                }

                else -> {}
            }
        }
    }

    private var countDownTimer: CountDownTimer? = null

    private val _countDown = MutableLiveData<Int>()
    val countDown: LiveData<Int> = _countDown

    private val _canSendCode = MutableLiveData(false)
    val canSendCode: LiveData<Boolean> = _canSendCode

    fun startCountDown(totalSeconds: Int = 60) {
        _canSendCode.value = false

        countDownTimer = object : CountDownTimer(totalSeconds * 1000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                _countDown.value = (millisUntilFinished / 1000).toInt()
            }

            override fun onFinish() {
                _countDown.value = 0
                _canSendCode.value = true
            }
        }.start()
    }

    fun isCanSendCode(isSend: Boolean) {
        _canSendCode.value = isSend
    }

    override fun onCleared() {
        countDownTimer?.cancel()
    }
}