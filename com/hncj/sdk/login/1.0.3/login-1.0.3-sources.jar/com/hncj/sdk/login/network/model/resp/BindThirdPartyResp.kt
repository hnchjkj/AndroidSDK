package com.hncj.sdk.login.network.model.resp

/**
 * date：2026-02-05 9:41
 * desc：
 */
data class BindThirdPartyResp(
    val avatar: String, // 头像
    val loginMode: String, // 登录方式
    val nickname: String, // 昵称
    val token: String, // 令牌
    val userId: Long // 用户id
)