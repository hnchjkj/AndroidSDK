package com.hncj.sdk.login.activity

import android.content.Context
import android.content.Intent
import androidx.lifecycle.lifecycleScope
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.ext.onThrottleClick
import com.hncj.sdk.core.ext.toast
import com.hncj.sdk.core.ui.BaseActivity
import com.hncj.sdk.login.R
import com.hncj.sdk.login.databinding.ActivityAccountSettingEmailBinding
import com.hncj.sdk.login.network.RequestClient
import com.hncj.sdk.login.network.Result
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

internal class AccountSettingEmailActivity : BaseActivity<ActivityAccountSettingEmailBinding>() {

    companion object {
        fun start(context: Context, isBind: Boolean) {
            context.startActivity(
                Intent(context, AccountSettingEmailActivity::class.java).apply {
                    putExtra("isBind", isBind)
                }
            )
        }
    }

    override fun initViews() {
        mDataBinding.apply {
            mustBackAny.onThrottleClick {
                finish()
            }

            mustSendTv.onThrottleClick {
                sendCode()
            }

            mustContinueAny.onThrottleClick {
                val email = mDataBinding.mustEmailEt.text.toString()
                val code = mDataBinding.mustCodeEt.text.toString()
                if (email.isEmpty()) {
                    toast(getString(R.string.toast_account_setting_email_empty))
                    return@onThrottleClick
                }
                if (code.isEmpty()) {
                    toast(getString(R.string.toast_account_setting_code_empty))
                    return@onThrottleClick
                }
                if (isEmailValid(email).not()) {
                    toast(getString(R.string.toast_account_setting_email_error))
                    return@onThrottleClick
                }
                lifecycleScope.launch {
                    if (intent.getBooleanExtra("isBind", false)) {
                        when (val result =
                            RequestClient.repository.replaceThirdPartyBind("email", email, code)) {
                            is Result.Success -> {
                                toast(getString(R.string.toast_change_success))
                                finish()
                            }

                            is Result.Error -> {
                                toast(getString(R.string.toast_change_failed))
                            }

                            else -> {}
                        }
                    } else {
                        when (val result =
                            RequestClient.repository.bindThirdParty("email", email, code)) {
                            is Result.Success -> {
                                ConfigCache.token = result.data.token
                                toast(getString(R.string.toast_change_success))
                                finish()
                            }

                            is Result.Error -> {
                                toast(getString(R.string.toast_change_failed))
                            }

                            else -> {}
                        }
                    }
                }
            }
        }
    }

    private fun sendCode() {
        val email = mDataBinding.mustEmailEt.text.toString()
        if (email.isEmpty()) {
            toast(getString(R.string.toast_account_setting_email_empty))
            return
        }

        if (isEmailValid(email)) {
            lifecycleScope.launch {
                when (val result = RequestClient.repository.sendLoginCodeEmail(email)) {
                    is Result.Success -> {
                        toast(getString(R.string.toast_send_success))
                        startCountdown()
                    }

                    is Result.Error -> {
                        toast(getString(R.string.toast_send_failed))
                    }

                    else -> {}
                }
            }
        } else {
            toast(getString(R.string.toast_account_setting_email_error))
        }
    }

    private fun startCountdown() {
        lifecycleScope.launch(Dispatchers.IO) {
            var cur = 60
            do {
                if (cur == 0) {
                    withContext(Dispatchers.Main) {
                        mDataBinding.mustSendTv.isEnabled = true
                        mDataBinding.mustSendTv.text =
                            getString(R.string.btn_account_setting_send)
                    }
                    continue
                } else {
                    withContext(Dispatchers.Main) {
                        mDataBinding.mustSendTv.isEnabled = false
                        mDataBinding.mustSendTv.text = "${cur}s"
                    }
                }
                delay(1000)
                cur--
            } while (true)
        }
    }

    private fun isEmailValid(email: String): Boolean {
        val regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$".toRegex()
        return regex.matches(email)
    }

    override fun statusBarDarkFont(): Boolean {
        return true
    }

    override fun initDataObserver() {}

    override fun getLayoutId(): Int {
        return R.layout.activity_account_setting_email
    }
}