package com.hncj.sdk.login.repository.impl

import android.content.Context
import android.content.Intent
import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.api.ThirdAuthResult
import com.hncj.sdk.login.repository.authActivity.LoginCallbackStore
import com.hncj.sdk.login.repository.authActivity.NaverAuthActivity
import com.navercorp.nid.NaverIdLoginSDK
import java.util.UUID

object NaverAuthSDK {

    private var isInitialized = false

    /**
     * SDK 对外唯一入口
     */
    fun login(
        context: Context,
        clientId: String,
        clientSecret: String,
        appName: String,
        callback: SignInCallback
    ) {

        ensureInit(context, clientId, clientSecret, appName)

                val requestId = UUID.randomUUID().toString()
        LoginCallbackStore.put(requestId, callback)

        val intent = Intent(context, NaverAuthActivity::class.java).apply {
            putExtra(NaverAuthActivity.EXTRA_REQUEST_ID, requestId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    /**
     * SDK 内部兜底初始化（只执行一次）
     */
    private fun ensureInit(
        context: Context,
        clientId: String,
        clientSecret: String,
        appName: String
    ) {
        if (isInitialized) return

        NaverIdLoginSDK.initialize(
            context.applicationContext,
            clientId,
            clientSecret,
            appName
        )
        isInitialized = true
    }

}