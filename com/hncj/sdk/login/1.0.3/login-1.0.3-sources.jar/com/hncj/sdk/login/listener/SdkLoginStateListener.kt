package com.hncj.sdk.login.listener

import com.hncj.sdk.login.network.model.resp.LoginResp

interface SdkLoginStateListener {
    fun onLoginSuccess(loginResult: LoginResp)
    fun onLoginFailed(code: Int = -1, msg: String? = "") {}
    fun onLoginOutSuccess()
    fun onLoginOutOnFailed(code: Int = -1, msg: String? = "") {}
    fun onDeactivateAccountSuccess()
    fun oneDactivateAccountFailed(code: Int = -1, msg: String? = "") {}
}