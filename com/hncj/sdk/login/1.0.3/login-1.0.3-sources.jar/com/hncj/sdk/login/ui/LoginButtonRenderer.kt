package com.hncj.sdk.login.ui
import android.widget.LinearLayout
import com.hncj.sdk.login.repository.config.LoginButtonConfig

object LoginButtonRenderer {
    /**
     * @param container 外层容器
     * @param buttons 所有按钮配置
     * @param columns 每行按钮数（竖屏=3，横屏=6 或 4）
     */
    fun render(
        container: LinearLayout,
        buttons: List<LoginButtonConfig>,
        columns: Int
    ) {
        container.removeAllViews()


        val visibleButtons = buttons.filter { it.visible }
        val rows = visibleButtons.chunked(columns)


        rows.forEach { rowButtons ->
            val row = LinearLayout(container.context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER
            }


            rowButtons.forEach { config ->
                val btn = LoginCircleButton(container.context)
                val lp = LinearLayout.LayoutParams(72.dp, 72.dp)
                lp.marginStart = 8.dp
                lp.marginEnd = 8.dp
                btn.layoutParams = lp
                btn.bind(config)
                row.addView(btn)
            }


            container.addView(row)
        }
    }
}