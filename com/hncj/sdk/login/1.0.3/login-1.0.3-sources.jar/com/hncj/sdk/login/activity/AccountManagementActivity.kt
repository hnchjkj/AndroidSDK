package com.hncj.sdk.login.activity

import android.content.Context
import android.content.Intent
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.hncj.sdk.core.cache.CacheFactory
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.ext.gone
import com.hncj.sdk.core.ext.onThrottleClick
import com.hncj.sdk.core.ext.toast
import com.hncj.sdk.core.ext.visible
import com.hncj.sdk.core.ui.BaseActivity
import com.hncj.sdk.core.utils.LoadingDialogHelper
import com.hncj.sdk.login.R
import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.api.ThirdAuthResult
import com.hncj.sdk.login.databinding.ActivityAccountManagementBinding
import com.hncj.sdk.login.network.RequestClient
import com.hncj.sdk.login.network.Result
import com.hncj.sdk.login.network.model.resp.AccountManagementItem
import com.hncj.sdk.login.repository.authActivity.FaceBookAuthActivity
import com.hncj.sdk.login.repository.authActivity.LineAuthActivity
import com.hncj.sdk.login.repository.authActivity.LoginCallbackStore
import com.hncj.sdk.login.repository.config.LoginType
import com.hncj.sdk.login.repository.impl.GoogleAuthProviderImp
import com.hncj.sdk.login.repository.impl.NaverAuthSDK
import com.hncj.sdk.login.repository.impl.TwitterAuthImp
import com.twitter.sdk.android.core.TwitterAuthConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

internal class AccountManagementActivity : BaseActivity<ActivityAccountManagementBinding>() {

    companion object {
        fun start(context: Context) {
            context.startActivity(
                Intent(context, AccountManagementActivity::class.java).apply {

                }
            )
        }
    }

    private val mAdapter = AccountManagementAdapter()

    override fun initViews() {
        mDataBinding.apply {
            mustBackAny.onThrottleClick {
                finish()
            }

            mustRecyclerView.apply {
                layoutManager = LinearLayoutManager(this@AccountManagementActivity)
                adapter = mAdapter
            }
        }

        mAdapter.setOnItemClickListener { adapter, view, position ->
            val data = mAdapter.data[position]
            if (data.loginType == "email") {
                // 邮箱
                AccountSettingEmailActivity.start(this@AccountManagementActivity, data.isBind)
                return@setOnItemClickListener
            }
            if (data.isBind) {
                AccountSettingActivity.start(this@AccountManagementActivity, data)
            } else {
                doAuth(data.loginType)
            }
        }

//        mAdapter.setList(
//            arrayListOf(
//                AccountManagementItem(
//                    loginTypeIcon = "",
//                    loginTypeDesc = "Email",
//                    loginType = "email",
//                    isBind = true,
//                    thirdPartyNickName = "Dawei.zhoucc@gmail.c"
//                ),
//                AccountManagementItem(
//                    loginTypeIcon = "",
//                    loginTypeDesc = "Google",
//                    loginType = "google",
//                    isBind = true,
//                    thirdPartyNickName = "David"
//                ),
//                AccountManagementItem(
//                    loginTypeIcon = "",
//                    loginTypeDesc = "Facebook",
//                    loginType = "facebook",
//                    isBind = false,
//                    thirdPartyNickName = ""
//                ),
//            )
//        )
    }

    override fun onResume() {
        super.onResume()
        if (mInBind.not()) {
            queryThirdBindList()
        }
    }

    private fun queryThirdBindList() {
        val loadingDialog = LoadingDialogHelper.getLoadingDialog(this)
        loadingDialog.show()
        lifecycleScope.launch {
            when (val result = RequestClient.repository.queryThirdBindList()) {
                is Result.Success -> {
                    withContext(Dispatchers.Main) {
                        loadingDialog.dismiss()
                        mAdapter.setList(result.data)
                    }
                }

                is Result.Error -> {
                    withContext(Dispatchers.Main) {
                        loadingDialog.dismiss()
                    }
                }

                else -> {}
            }
        }
    }

    private var mInBind = false
    private fun doAuth(loginType: String) {
        mInBind = true
        val loginConfigList = ConfigCache.getVendorLoginConfigList()
        when (loginType) {
            LoginType.GOOGLE.value -> {
                loginConfigList.find { it.loginType == LoginType.GOOGLE.value }?.apply {
                    authGoogle(clientId) { loginCode, loginKey ->
                        requestBind(loginType, loginCode, loginKey)
                    }
                }
            }

            LoginType.FACEBOOK.value -> {
                loginConfigList.find { it.loginType == LoginType.FACEBOOK.value }?.apply {
                    authFacebook { loginCode, loginKey ->
                        requestBind(loginType, loginCode, loginKey)
                    }
                }
            }

            LoginType.TWITTER.value -> {
                loginConfigList.find { it.loginType == LoginType.TWITTER.value }?.apply {
                    authTwitter(
                        TwitterAuthConfig(
                            clientId,
                            clientSecret
                        )
                    ) { loginCode, loginKey ->
                        requestBind(loginType, loginCode, loginKey)
                    }
                }
            }

            LoginType.LINE.value -> {
                loginConfigList.find { it.loginType == LoginType.LINE.value }?.apply {
                    authLine(clientId) { loginCode, loginKey ->
                        requestBind(loginType, loginCode, loginKey)
                    }
                }
            }

            LoginType.NAVER.value -> {
                loginConfigList.find { it.loginType == LoginType.NAVER.value }?.apply {
                    authNaver(clientId, clientSecret, "name") { loginCode, loginKey ->
                        requestBind(loginType, loginCode, loginKey)
                    }
                }
            }

            else -> {
                mInBind = false
            }
        }
    }

    private fun requestBind(loginMode: String, loginCode: String, loginKey: String) {
        val loadingDialog = LoadingDialogHelper.getLoadingDialog(this)
        loadingDialog.show()
        lifecycleScope.launch {
            when (val result =
                RequestClient.repository.bindThirdParty(loginMode, loginCode, loginKey)) {
                is Result.Success -> {
                    withContext(Dispatchers.Main) {
                        loadingDialog.dismiss()
                    }
                    ConfigCache.token = result.data.token
                    toast(getString(R.string.toast_bind_success))
                    mInBind = false
                    queryThirdBindList()
                }

                is Result.Error -> {
                    withContext(Dispatchers.Main) {
                        loadingDialog.dismiss()
                    }
                    mInBind = false
                    toast(getString(R.string.toast_bind_failed))
                }

                else -> {}
            }
        }
    }

    /**
     * GoogleAuth
     * */
    private fun authGoogle(
        serverClientId: String,
        callback: (loginCode: String, loginKey: String) -> Unit
    ) {
        val googleAuthProviderImp = GoogleAuthProviderImp(
            context = this,
            serverClientId = serverClientId
        )

        googleAuthProviderImp.signIn(
            object : SignInCallback {
                override fun onSuccessResult(result: ThirdAuthResult?) {
                    callback.invoke(result?.accessToken!!, "")
                }

                override fun onFailure(e: Exception?) {
                    toast(getString(R.string.auth_failed))
                }
            }
        )
    }

    /**
     * TwitterAuth
     * */
    private fun authTwitter(
        config: TwitterAuthConfig,
        callback: (loginCode: String, loginKey: String) -> Unit
    ) {
        val twitterAuthImp = TwitterAuthImp(this, config)
        twitterAuthImp.login(
            object : SignInCallback {
                override fun onSuccessResult(result: ThirdAuthResult?) {
                    callback.invoke(result?.accessToken!!, result.secret!!)
                }

                override fun onFailure(e: Exception?) {
                    toast(getString(R.string.auth_failed))
                }
            }
        )
    }

    /**
     * FacebookAuth
     * */
    private fun authFacebook(callback: (loginCode: String, loginKey: String) -> Unit) {
        val requestId = UUID.randomUUID().toString()
        LoginCallbackStore.put(
            requestId,
            object : SignInCallback {
                override fun onSuccessResult(result: ThirdAuthResult?) {
                    callback.invoke(result?.accessToken!!, "")
                }

                override fun onFailure(e: Exception?) {
                    toast(getString(R.string.auth_failed))
                }
            }
        )

        val intent = Intent(this, FaceBookAuthActivity::class.java).apply {
            putExtra(LineAuthActivity.EXTRA_REQUEST_ID, requestId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        startActivity(intent)
    }

    /**
     * LineAuth
     * */
    private fun authLine(
        key: String,
        callback: (loginCode: String, loginKey: String) -> Unit
    ) {
        val requestId = UUID.randomUUID().toString()
        LoginCallbackStore.put(
            requestId,
            object : SignInCallback {
                override fun onSuccessResult(result: ThirdAuthResult?) {
                    callback.invoke(result?.accessToken!!, "")
                }

                override fun onFailure(e: Exception?) {
                    toast(getString(R.string.auth_failed))
                }
            }
        )

        val intent = Intent(this, LineAuthActivity::class.java).apply {
            putExtra(LineAuthActivity.EXTRA_CHANNEL_ID, key)
            putExtra(LineAuthActivity.EXTRA_REQUEST_ID, requestId)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        startActivity(intent)
    }

    /**
     * NaverAuth
     */
    private fun authNaver(
        serverClientId: String,
        serverSecret: String,
        appName: String,
        callback: (loginCode: String, loginKey: String) -> Unit
    ) {
        NaverAuthSDK.login(
            context = this,
            clientId = serverClientId,
            clientSecret = serverSecret,
            appName = appName,
            callback = object : SignInCallback {
                override fun onSuccessResult(result: ThirdAuthResult?) {
                    callback.invoke(result?.accessToken!!, result.secret!!)
                }

                override fun onFailure(e: Exception?) {
                    toast(getString(R.string.auth_failed))
                }
            }
        )
    }

    override fun statusBarDarkFont(): Boolean {
        return true
    }

    override fun initDataObserver() {}

    override fun getLayoutId(): Int {
        return R.layout.activity_account_management
    }
}

class AccountManagementAdapter :
    BaseQuickAdapter<AccountManagementItem, BaseViewHolder>(R.layout.item_account_management) {
    override fun convert(holder: BaseViewHolder, item: AccountManagementItem) {
        val must_icon_iv = holder.getViewOrNull<ImageView>(R.id.must_icon_iv)
        val must_title_tv = holder.getViewOrNull<TextView>(R.id.must_title_tv)
        val must_state_tv = holder.getViewOrNull<TextView>(R.id.must_state_tv)
        val must_content_tv = holder.getViewOrNull<TextView>(R.id.must_content_tv)

        must_icon_iv?.let {
            Glide.with(it)
                .load(item.loginTypeIcon)
                .into(it)
        }

        must_title_tv?.text = item.loginTypeDesc
        must_content_tv?.text = item.thirdPartyNickName

        if (item.isBind) {
            must_content_tv?.visible()
            must_state_tv?.text = context.getString(R.string.state_item_account_management_yes)
        } else {
            must_content_tv?.gone()
            must_state_tv?.text = context.getString(R.string.state_item_account_management_no)
        }
    }
}