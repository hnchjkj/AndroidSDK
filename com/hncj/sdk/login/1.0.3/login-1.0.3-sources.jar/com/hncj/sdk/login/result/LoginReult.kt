package com.hncj.sdk.login.result

data class LoginReult (
    val userId: String
)