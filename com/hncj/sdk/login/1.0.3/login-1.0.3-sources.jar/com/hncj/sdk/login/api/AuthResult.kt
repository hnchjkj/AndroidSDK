package com.hncj.sdk.login.api

sealed class AuthResult {
    data class Success(val user: AuthUser) : AuthResult()
    data class Error(val message: String) : AuthResult()
}
interface InitCallback {
    fun onSuccess(isInit: Boolean)
}

data class ThirdAuthResult(
    val accessToken: String?,
    val secret: String?,
)


interface SignInCallback {
    /// 回调走这个
    fun onSuccessResult(result: ThirdAuthResult?)
    fun onFailure(e: Exception?=null)
    fun onCancel() {}
}
