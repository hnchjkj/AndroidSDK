package com.hncj.sdk.login;

@androidx.databinding.BindingBuildInfo
public class DataBindingTriggerClass {}