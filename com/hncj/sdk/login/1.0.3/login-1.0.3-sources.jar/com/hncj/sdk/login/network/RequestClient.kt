package com.hncj.sdk.login.network

import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.utils.LOG
import com.hncj.sdk.login.network.service.RepositoryImpl
import com.hncj.sdk.login.network.service.Repository

internal object RequestClient {
    lateinit var repository: Repository

    fun init(callback: () -> Unit) {
        if (ConfigCache.serverDomain.isNotEmpty()) {
            repository = RepositoryImpl(ConfigCache.serverDomain)
            if (::repository.isInitialized) {
                callback.invoke()
            }
        } else {
            LOG.e(LOG.LOGIN_TAG_HTTP, "server init failure, domain is empty")
        }
    }
}