package com.hncj.sdk.login.repository.authActivity

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.hncj.sdk.login.api.ThirdAuthResult
import com.navercorp.nid.NaverIdLoginSDK
import com.navercorp.nid.oauth.OAuthLoginCallback

class NaverAuthActivity : FragmentActivity() {

    companion object {
        const val EXTRA_REQUEST_ID = "request_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 防止重复启动
        if (savedInstanceState != null) {
            finish()
            return
        }

        startNaverLogin()
    }

    private fun startNaverLogin() {
        NaverIdLoginSDK.authenticate(this, object : OAuthLoginCallback {

            override fun onSuccess() {
                val accessToken = NaverIdLoginSDK.getAccessToken()
                if (accessToken.isNullOrEmpty()) {
                    LoginCallbackStore.failure(
                        intent.getStringExtra(EXTRA_REQUEST_ID),
                        Exception("Auth failed")
                    )
                } else {
                    notifySuccess(
                        ThirdAuthResult(
                            accessToken,
                            ""
                        )
                    )
                }
            }

            override fun onFailure(httpStatus: Int, message: String) {
                notifyFailure(Exception(message))
            }

            override fun onError(errorCode: Int, message: String) {
                notifyFailure(Exception(message))
            }
        })
    }

    /**
     * 登录成功
     */
    private fun notifySuccess(result: ThirdAuthResult) {
        LoginCallbackStore.success(
            intent.getStringExtra(LineAuthActivity.EXTRA_REQUEST_ID),
            result
        )
        finish()
    }

    /**
     * 登录失败
     */
    private fun notifyFailure(e: java.lang.Exception) {
        LoginCallbackStore.failure(
            intent.getStringExtra(LineAuthActivity.EXTRA_REQUEST_ID),
            e
        )
        finish()
    }
}