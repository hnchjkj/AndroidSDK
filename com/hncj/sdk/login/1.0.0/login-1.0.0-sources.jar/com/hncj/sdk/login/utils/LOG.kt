package com.hncj.sdk.login.utils

import androidx.annotation.RestrictTo
import com.hncj.sdk.login.CJAuthSdk

import org.jetbrains.annotations.NonNls

@RestrictTo(RestrictTo.Scope.LIBRARY)
object LOG {

    private var isInit = false

    const val TAG = "CJAuthSdk"
    const val TAG_HTTP = "CJAuthSdk.Http"

    private val mLogger = object : Timber.DebugTree() {
        override fun isLoggable(tag: String?, priority: Int): Boolean {
            return CJAuthSdk.isDebug
        }

        override fun formatMessage(message: String, args: Array<out Any?>): String {
            return message
        }
    }

    fun init() {
        if (isInit) return
        Timber.plant(mLogger)
        isInit = true
    }

    fun v(tag: String, message: String?, vararg args: Any?) {
        Timber.tag(tag).v(message, args)
    }

    fun v(tag: String, t: Throwable?, @NonNls message: String?, vararg args: Any?) {
        Timber.tag(tag).v(t, message, args)
    }

    fun v(tag: String, t: Throwable?) {
        Timber.tag(tag).v(t)
    }

    /** Log a debug message with optional format args. */
    fun d(tag: String, message: String?, vararg args: Any?) {
        Timber.tag(tag).d(message, args)
    }

    /** Log a debug exception and a message with optional format args. */
    fun d(tag: String, t: Throwable?, message: String?, vararg args: Any?) {
        Timber.tag(tag).d(t, message, args)
    }

    /** Log a debug exception. */
    fun d(tag: String, t: Throwable?) {
        Timber.tag(tag).d(t)
    }

    /** Log an info message with optional format args. */
    fun i(tag: String, message: String?, vararg args: Any?) {
        Timber.tag(tag).i(message, args)
    }

    /** Log an info exception and a message with optional format args. */
    fun i(tag: String, t: Throwable?, message: String?, vararg args: Any?) {
        Timber.tag(tag).i(t, message, args)
    }

    /** Log an info exception. */
    fun i(tag: String, t: Throwable?) {
        Timber.tag(tag).i(t)
    }

    /** Log a warning message with optional format args. */
    fun w(tag: String, message: String?, vararg args: Any?) {
        Timber.tag(tag).w(message, args)
    }

    /** Log a warning exception and a message with optional format args. */
    fun w(tag: String, t: Throwable?, message: String?, vararg args: Any?) {
        Timber.tag(tag).w(t, message, args)
    }

    /** Log a warning exception. */
    fun w(tag: String, t: Throwable?) {
        Timber.tag(tag).w(t)
    }

    /** Log an error message with optional format args. */
    fun e(tag: String, message: String?, vararg args: Any?) {
        Timber.tag(tag).e(message, args)
    }

    /** Log an error exception and a message with optional format args. */
    fun e(tag: String, t: Throwable?, message: String?, vararg args: Any?) {
        Timber.tag(tag).e(t, message, args)
    }

    /** Log an error exception. */
    fun e(tag: String, t: Throwable?) {
        Timber.tag(tag).e(t)
    }

    /** Log an assert message with optional format args. */
    fun wtf(tag: String, message: String?, vararg args: Any?) {
        Timber.tag(tag).wtf(message, args)
    }

    /** Log an assert exception and a message with optional format args. */
    fun wtf(tag: String, t: Throwable?, message: String?, vararg args: Any?) {
        Timber.tag(tag).wtf(t, message, args)
    }

    /** Log an assert exception. */
    fun wtf(tag: String, t: Throwable?) {
        Timber.tag(tag).wtf(t)
    }
}