package com.hncj.sdk.login.network

import android.os.Build
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.login.ext.currentSeconds
import com.hncj.sdk.login.ext.gson
import com.hncj.sdk.login.utils.EncryptUtils
import com.hncj.sdk.login.utils.LOG
import okhttp3.FormBody
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.net.URL
import java.net.URLDecoder
import java.util.Locale

internal class RequestInterceptor : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()
        if (request.method == "POST") {
            val body = request.body
            if (body != null && body is FormBody) {
                val hashParam = hashMapOf<String, String>()
                for (i in 0 until body.size) {
                    hashParam[body.encodedName(i)] = URLDecoder.decode( body.encodedValue(i) )
                }
                val paramJson = gson.toJson(hashParam)
                LOG.d(
                    LOG.TAG_HTTP,
                    "request -> $paramJson"
                )
                val requestBody = paramJson.toRequestBody(
                    "application/json;charset=utf-8".toMediaTypeOrNull()
                )
                val requestBuilder = request.newBuilder()

                val timestamp = System.currentTimeMillis() / 1000L
                val hasTimeUrl = "${request.url}?t=${timestamp}"
                val hasTimePath = "${request.url.encodedPath}?t=${timestamp}"
                val appSecret = ConfigCache.appSecret
                val sign = EncryptUtils.encrypt(hasTimePath, paramJson, appSecret)

                if (sign.isNotEmpty()) {
                    requestBuilder.addHeader("x-sign", sign)
                }
                val appKey = ConfigCache.appKey
                if (appKey.isNotEmpty()) {
                    requestBuilder.addHeader("x-appKey", appKey)
                }

                val token = ConfigCache.token
                if (token.isNotEmpty()) {
                    requestBuilder.addHeader("Authorization", token)
                }
                requestBuilder.addHeader("x-platform", "Android")
                requestBuilder.addHeader("x-area", Locale.getDefault().country)
                requestBuilder.addHeader("x-device-model", "${Build.MANUFACTURER} ${Build.MODEL}")
                requestBuilder.post(requestBody).url(hasTimeUrl)
                request = requestBuilder.build()
            }
        }

        return chain.proceed(request)
    }
}