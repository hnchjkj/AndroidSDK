package com.hncj.sdk.login.network

import com.hncj.sdk.login.ext.gson
import com.hncj.sdk.login.network.model.BaseResponse
import com.hncj.sdk.login.utils.LOG
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.net.HttpURLConnection

internal object ResultTransformer {

    suspend fun <T> asResult(
        networkCall: suspend () -> BaseResponse<T>,
        successCall: suspend (BaseResponse<T>) -> Unit = {},
        dispatcher: CoroutineDispatcher = Dispatchers.IO
    ): Result<T> {
        return asResult(networkCall, successCall, { it }, dispatcher)
    }

    suspend fun <T, R> asResult(
        networkCall: suspend () -> BaseResponse<T>,
        successCall: suspend (BaseResponse<T>) -> Unit = {},
        transformer: (T) -> R,
        dispatcher: CoroutineDispatcher = Dispatchers.IO
    ): Result<R> {
        return withContext(dispatcher) {
            try {
                val response = networkCall()
                if (response.isSuccess()) {
                    successCall(response)
                    Result.Success(transformer(response.data))
                } else {
                    Result.Error(BusinessException(response.code, response.msg))
                }
            } catch (e: Throwable) {
                handleException(e)
            }
        }
    }

    fun <T, R> asResultFlow(
        networkCall: suspend () -> BaseResponse<T>,
        successCall: suspend (BaseResponse<T>) -> Unit = {},
        transform: (T) -> R,
        dispatcher: CoroutineDispatcher = Dispatchers.IO
    ): Flow<Result<R>> = flow {
        emit(Result.Loading())
        val response = networkCall()
        if (response.isSuccess()) {
            successCall(response)
            emit(Result.Success(transform(response.data)))
        } else {
            emit(Result.Error(BusinessException(response.code, response.msg)))
        }
    }.flowOn(dispatcher).catch {
        emit(handleException(it))
    }

    /**
     * networkCall：使用retrofit请求网络数据
     * successCall：网络请求成功之后的操作
     * dispatcher：在哪个dispatcher执行
     */
    fun <T> asResultFlow(
        networkCall: suspend () -> BaseResponse<T>,
        successCall: suspend (BaseResponse<T>) -> Unit = {},
        dispatcher: CoroutineDispatcher = Dispatchers.IO,
        shouldLoading: Boolean = false
    ): Flow<Result<T>> = flow {
        if (shouldLoading) emit(Result.Loading())
        val response = networkCall()
        if (response.isSuccess()) {
            successCall(response)
            emit(Result.Success(response.data))
        } else {
            emit(Result.Error(BusinessException(response.code, response.msg)))
        }
    }.flowOn(dispatcher).catch {
        emit(handleException(it))
    }

    private fun handleException(e: Throwable): Result.Error {
        LOG.e(LOG.TAG_HTTP, e)
        if (e is HttpException) {
            // 登出
            if (e.code() == HttpURLConnection.HTTP_FORBIDDEN) {
                return Result.Error(BusinessException(e.code(), e.message))
            } else {
                val errorBody = e.response()?.errorBody()
                if (errorBody != null) {
                    try {
                        val errorResponse = gson.fromJson(
                            errorBody.charStream(), BaseResponse::class.java
                        )
                        return if (errorResponse != null) {
                            Result.Error(
                                BusinessException(
                                    errorResponse.code,
                                    errorResponse.msg
                                )
                            )
                        } else {
                            Result.Error(
                                BusinessException(
                                    Result.Error.ERROR_BUSINESS,
                                    e.message
                                )
                            )
                        }
                    } catch (e: Exception) {
                        return Result.Error(
                            BusinessException(
                                Result.Error.ERROR_BUSINESS, e.message
                            )
                        )
                    }
                } else {
                    return Result.Error(BusinessException(Result.Error.ERROR_BUSINESS, e.message))
                }
            }
        } else {
            return Result.Error(BusinessException(Result.Error.ERROR_BUSINESS, e.message))
        }
    }
}