package com.hncj.sdk.login.repository.authActivity

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.facebook.*
import com.facebook.login.LoginManager
import com.facebook.login.LoginResult
import com.google.firebase.auth.FacebookAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.hncj.sdk.login.R
import com.hncj.sdk.login.utils.LOG
import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.api.ThirdAuthResult
import com.hncj.sdk.login.repository.authActivity.LineAuthActivity.Companion.EXTRA_REQUEST_ID
import java.lang.Exception

internal class FaceBookAuthActivity : FragmentActivity() {

    private lateinit var callbackManager: CallbackManager
    private val firebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        callbackManager = CallbackManager.Factory.create()

        LOG.e("12345", "进来")
        startFacebookLogin()
    }

    /**
     * 发起 Facebook 登录
     */
    private fun startFacebookLogin() {
        LoginManager.getInstance().logInWithReadPermissions(
            this,
            listOf("email", "public_profile")
        )

        LoginManager.getInstance().registerCallback(
            callbackManager,
            object : FacebookCallback<LoginResult> {

                override fun onSuccess(result: LoginResult) {
                    notifySuccess(
                        ThirdAuthResult(
                            result.accessToken.token,
                            ""
                        )
                    )
//                    handleFacebookAccessToken(result.accessToken)
                }

                override fun onCancel() {
                    notifyFailure(Exception(getString(R.string.auth_cancel)))
                }

                override fun onError(error: FacebookException) {
                    notifyFailure(error)
                }
            }
        )
    }

    /**
     * Facebook token -> Firebase
     */
    private fun handleFacebookAccessToken(token: AccessToken) {
        val credential = FacebookAuthProvider.getCredential(token.token)

        firebaseAuth.signInWithCredential(credential)
            .addOnSuccessListener { authResult ->

                val user = authResult.user
                val accessToken = token.token

                notifySuccess(
                    ThirdAuthResult(
                        accessToken,
                        ""
                    )
                )
            }
            .addOnFailureListener {
                notifyFailure(it)
            }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        callbackManager.onActivityResult(requestCode, resultCode, data)
    }

    /**
     * 登录成功
     */
    private fun notifySuccess(result: ThirdAuthResult) {
//        FaceBookResultDispatcher.dispatchSuccess(result)
        LoginCallbackStore.success(
            intent.getStringExtra(EXTRA_REQUEST_ID),
            result
        )
        finish()
    }

    /**
     * 登录失败
     */
    private fun notifyFailure(e: Exception) {
        LoginCallbackStore.failure(
            intent.getStringExtra(EXTRA_REQUEST_ID),
            e
        )
//        FaceBookResultDispatcher.dispatchFailure(e)
        finish()
    }
}