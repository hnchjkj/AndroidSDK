package com.hncj.sdk.login
import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.utils.ToastUtils
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.login.utils.LOG
import com.hncj.sdk.login.api.SignInCallback
import com.hncj.sdk.login.listener.SdkLoginStateListener
import com.hncj.sdk.login.network.RequestClient
import com.hncj.sdk.login.network.Result
import com.hncj.sdk.login.provider.LoginCallbackHolder
import com.hncj.sdk.login.repository.LoginRepository
import com.hncj.sdk.login.repository.config.LoginType
import com.twitter.sdk.android.core.TwitterAuthConfig
import kotlinx.coroutines.launch


/**
 * date：2026-01-07 9:28
 * desc：
 * 长沙花之梦科技有限公司
 * huazhimeng2025@gmail.com
 * Huazhimeng123
 * cjtest.net
 * 13548663965
 * com.test.cj
 */
@SuppressLint("StaticFieldLeak")
object CJAuthSdk {

    private lateinit var manager: LoginRepository

    var isDebug = true

    private lateinit var mSdkLoginStateListener: SdkLoginStateListener

    /**
     * 初始化SDK
     * */
    fun init(sdkLoginStateListener: SdkLoginStateListener) {
        LOG.init()
        manager = LoginRepository()
        manager.init(sdkLoginStateListener)
        RequestClient.init()
        mSdkLoginStateListener = sdkLoginStateListener
    }

    /**
     * 授权
     * */
    fun gameAuth(type: LoginType, context: Context) {
        manager.initContext(context)
        if (type == LoginType.GUEST) {
            manager.loginAnonymously(type)
            return;
        }
        val loginTypeList = ConfigCache.getVendorLoginConfigList()
        val item = loginTypeList.firstOrNull { it.loginType == type.value }
        if (item == null) {
            return;
        }
        if (type == LoginType.GOOGLE) {
            manager.signInGoogle(type,item.clientId)
        }
        if (type == LoginType.TWITTER) {
            manager.loginTwitter( type,TwitterAuthConfig(
                item.clientId,
                item.clientSecret
            ))
        }
        if (type == LoginType.FACEBOOK) {
            manager.loginFacebook(type)
        }
        if (type == LoginType.LINE) {
            manager.loginLine(type,item.clientId);
        }
        if (type == LoginType.NAVER) {
            manager.loginNaver(type,item.clientId,item.clientSecret,"name");
        }
    }

    /**
     * 发送验证码
     */
    fun sendEmailCode(emailAddress: String, callback: SignInCallback) {
        Utils.mCoroutineScope.launch {
            when (val result = RequestClient.repository.sendLoginCodeEmail(emailAddress)) {
                is Result.Success -> {
                    callback.onSuccessResult(null)
                }

                is Result.Error -> {
                    callback.onFailure(Exception(result.error.errorMessage))
                }

                else -> {}
            }
        }
    }


    /**
     * 邮箱登录
     */
    fun emailCodeLogin(emailAddress: String, emailCode: String) {
        manager.emailCodeLogin(emailAddress,emailCode)
    }


    /**
     * 弹出登录页面
     */
    fun showLoginActivity() {
        manager.showLoginActivity(mSdkLoginStateListener)
    }

    /**
     * 登出
     * */
    fun loginOut() {
        manager.loginOut(mSdkLoginStateListener)
    }

    /**
     * 账号注销
     * */
    fun deactivateAccount() {
        manager.deactivateAccount(mSdkLoginStateListener)
    }
}