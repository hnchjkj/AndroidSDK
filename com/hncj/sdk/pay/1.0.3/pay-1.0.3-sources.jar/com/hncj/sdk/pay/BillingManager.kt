package com.hncj.sdk.pay

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.hncj.sdk.core.ext.gson
import com.hncj.sdk.core.utils.LOG
import com.hncj.sdk.core.utils.ToastUtils
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.pay.local.PayCache
import com.hncj.sdk.pay.local.model.GooglePaymentRecord
import com.hncj.sdk.pay.local.model.GooglePaymentRecordItem
import com.hncj.sdk.pay.network.RequestClient
import com.hncj.sdk.pay.network.Result
import com.hncj.sdk.pay.utils.FlowRetryUtils
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * date：2026-01-07 19:42
 * desc：
 */
internal object BillingManager {
    private lateinit var mBillingClient: BillingClient

    private var mIsConnected = false

    private val mGooglePaymentRecord = arrayListOf<GooglePaymentRecordItem>()

    init {
        mGooglePaymentRecord.clear()
        mGooglePaymentRecord.addAll(
            gson.fromJson(
                PayCache.jsonGooglePaymentRecord.ifEmpty { "[]" },
                GooglePaymentRecord::class.java
            )
        )
    }

    fun addPaymentRecord(orderId: String, productId: String) {
        val localRecord = mGooglePaymentRecord.find { it.orderId == orderId }
        if (localRecord == null) {
            mGooglePaymentRecord.add(GooglePaymentRecordItem(orderId, productId))
            PayCache.jsonGooglePaymentRecord = gson.toJson(mGooglePaymentRecord)
        }
    }

    private val mPurchasesUpdatedListener =
        PurchasesUpdatedListener { billingResult, purchases ->
            // 处理购买结果
            when (billingResult.responseCode) {
                BillingClient.BillingResponseCode.OK -> {
                    LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "PurchasesUpdated -> ok")
                    purchases?.let {
                        // 处理每个购买的结果
                        it.forEach { purchase ->
                            handlePurchase(purchase)
                        }
                    }
                }

                BillingClient.BillingResponseCode.USER_CANCELED -> {
                    LOG.d(
                        LOG.PAY_TAG_GOOGLE_PAY,
                        "PurchasesUpdated -> user canceled"
                    )
                }

                else -> {
                    LOG.e(
                        LOG.PAY_TAG_GOOGLE_PAY,
                        "PurchasesUpdated -> error, $billingResult"
                    )
                }
            }
        }

    private val mBillingClientStateListener = object : BillingClientStateListener {
        override fun onBillingServiceDisconnected() {
            mIsConnected = false
            LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClientState -> disconnected")

            LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> try reconnect")
            startConnection()
        }

        override fun onBillingSetupFinished(billingResult: BillingResult) {
            mIsConnected = billingResult.responseCode == BillingClient.BillingResponseCode.OK
            when (billingResult.responseCode) {
                BillingClient.BillingResponseCode.OK -> {
                    LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClientState -> isReady")

                    restorePurchases()
                }

                else -> {
                    LOG.e(
                        LOG.PAY_TAG_GOOGLE_PAY,
                        "BillingClientState -> error, ${billingResult.debugMessage}"
                    )
                }
            }
        }
    }

    fun init(context: Context) {
        LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> start init")
        if (::mBillingClient.isInitialized) {
            LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> isInitialized, skip")
            return
        }
        mBillingClient = BillingClient.newBuilder(context)
            .setListener(mPurchasesUpdatedListener)
            .enablePendingPurchases(
                PendingPurchasesParams.newBuilder()
                    .enableOneTimeProducts()
                    .build()
            )
            .build()

        startConnection()
    }

    private fun startConnection() {
        LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> start connect")
        if (::mBillingClient.isInitialized) {
            if (mIsConnected) {
                LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> isConnected, skip")
                return
            }
            mBillingClient.startConnection(mBillingClientStateListener)
        } else {
            LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "client not init, skip")
        }
    }

    fun doPay(
        activity: Activity,
        productId: String
    ) {
        // 先查询商品信息
        queryProduct(
            productId,
            onSuccess = { productDetails ->
                // 发起购买
                requestBuy(activity, productDetails)
            }
        )
    }

    private fun requestBuy(activity: Activity, productDetails: ProductDetails) {
        val offerToken = productDetails.oneTimePurchaseOfferDetails?.offerToken
        if (offerToken != null) {
            val productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(productDetails)
                .setOfferToken(offerToken)
                .build()

            val billingFlowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(listOf(productParams))
                .build()

            if (::mBillingClient.isInitialized) {
                mBillingClient.launchBillingFlow(activity, billingFlowParams)
            } else {
                ToastUtils.showShort(Utils.app.getString(R.string.error_start_pay))
                LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "client not init, skip")
            }
        } else {
            ToastUtils.showShort(Utils.app.getString(R.string.error_start_pay))
            LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> offerToken null, skip")
        }
    }

    /**
     * 查询商品
     */
    private fun queryProduct(
        productId: String,
        onSuccess: (ProductDetails) -> Unit
    ) {
        LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> start query product")
        val productList = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(productId)
                .setProductType(BillingClient.ProductType.INAPP)
                .build()
        )

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        if (::mBillingClient.isInitialized) {
            mBillingClient.queryProductDetailsAsync(params) { billingResult, queryProductDetailsResult ->
                when (billingResult.responseCode) {
                    BillingClient.BillingResponseCode.OK -> {
                        val productDetailsList = queryProductDetailsResult.productDetailsList
                        if (productDetailsList.isNotEmpty()) {
                            val productDetails = productDetailsList[0]
                            onSuccess.invoke(productDetails)
                            LOG.d(
                                LOG.PAY_TAG_GOOGLE_PAY,
                                "BillingClient -> query product ok, ${productDetails.name}"
                            )
                        } else {
                            ToastUtils.showShort(Utils.app.getString(R.string.error_start_pay))
                            LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> query product, no product")
                        }
                    }

                    else -> {
                        ToastUtils.showShort(Utils.app.getString(R.string.error_start_pay))
                        LOG.e(
                            LOG.PAY_TAG_GOOGLE_PAY,
                            "BillingClient -> query product error, ${billingResult.debugMessage}"
                        )
                    }
                }
            }
        } else {
            ToastUtils.showShort(Utils.app.getString(R.string.error_start_pay))
            LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "client not init, skip")
        }
    }

    /**
     * 处理购买结果
     */
    private fun handlePurchase(purchase: Purchase) {
        if (::mBillingClient.isInitialized) {
            when (purchase.purchaseState) {
                Purchase.PurchaseState.PURCHASED -> {
                    // 购买完成后确认或处理订阅
                    LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> purchase state ok")
                    LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> start verify")
                    Utils.mCoroutineScope.launch {
                        val productId = purchase.products.getOrNull(0).orEmpty()
                        var payOrderId = ""
                        if (productId.isEmpty()) {
                            LOG.e(
                                LOG.PAY_TAG_GOOGLE_PAY,
                                "BillingClient -> verify error, unknown product_id"
                            )
                            return@launch
                        }
                        mGooglePaymentRecord.find { it.productId == productId }?.let {
                            payOrderId = it.orderId
                        }
                        if (payOrderId.isEmpty()) {
                            LOG.e(
                                LOG.PAY_TAG_GOOGLE_PAY,
                                "BillingClient -> verify error, unknown pay_order_id"
                            )
                            return@launch
                        }
                        FlowRetryUtils().executeWithRetry {
                            RequestClient.repository.verify(
                                payOrderId,
                                productId,
                                purchase.orderId.orEmpty(),
                                purchase.purchaseToken
                            )
                        }.collectLatest {
                            when (it) {
                                is Result.Success -> {
                                    consumePurchase(purchase)
                                }

                                is Result.Error -> {
                                    LOG.e(
                                        LOG.PAY_TAG_GOOGLE_PAY,
                                        "BillingClient -> verify error, ${it.error.errorMessage}"
                                    )
                                }

                                else -> {}
                            }
                        }
                    }
                    // 确认购买（对于非消耗品和订阅必须确认）
//                    val acknowledgePurchaseParams =
//                        AcknowledgePurchaseParams.newBuilder()
//                            .setPurchaseToken(purchase.purchaseToken)
//                            .build()
//
//                    LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> start acknowledge")
//                    mBillingClient.acknowledgePurchase(acknowledgePurchaseParams) {
//                        when (it.responseCode) {
//                            BillingClient.BillingResponseCode.OK -> {
//                                LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> acknowledge ok")
//                            }
//
//                            else -> {
//                                LOG.e(
//                                    LOG.PAY_TAG_GOOGLE_PAY,
//                                    "BillingClient -> acknowledge error, ${it.debugMessage}"
//                                )
//                            }
//                        }
//                    }
                }

                Purchase.PurchaseState.PENDING -> {
                    LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> purchase state pending")
                }

                else -> {
                    LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> purchase state error")
                }
            }
        } else {
            LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "client not init, skip")
        }
    }

    private fun restorePurchases() {
        LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> start restore purchases")
        if (::mBillingClient.isInitialized) {
            mBillingClient.queryPurchasesAsync(
                QueryPurchasesParams.newBuilder()
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build()
            ) { billingResult, purchases ->
                when (billingResult.responseCode) {
                    BillingClient.BillingResponseCode.OK -> {
                        if (purchases.isEmpty()) {
                            LOG.d(
                                LOG.PAY_TAG_GOOGLE_PAY,
                                "BillingClient -> restore purchases end"
                            )
                        }
                        purchases.forEach {
                            handlePurchase(it)
                        }
                    }

                    else -> {
                        LOG.e(
                            LOG.PAY_TAG_GOOGLE_PAY,
                            "BillingClient -> restore purchases error, ${billingResult.debugMessage}"
                        )
                    }
                }
            }
        } else {
            LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "client not init, skip")
        }
    }

    private fun consumePurchase(purchase: Purchase) {
        LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> start consume")
        if (::mBillingClient.isInitialized) {
            val consumeParams = ConsumeParams.newBuilder()
                .setPurchaseToken(purchase.purchaseToken)
                .build()

            mBillingClient.consumeAsync(consumeParams) { billingResult, _ ->
                when (billingResult.responseCode) {
                    BillingClient.BillingResponseCode.OK -> {
                        LOG.d(LOG.PAY_TAG_GOOGLE_PAY, "BillingClient -> consume ok")
                    }

                    else -> {
                        LOG.e(
                            LOG.PAY_TAG_GOOGLE_PAY,
                            "BillingClient -> consume erroe, ${billingResult.debugMessage}"
                        )
                    }
                }
            }
        } else {
            LOG.e(LOG.PAY_TAG_GOOGLE_PAY, "client not init, skip")
        }
    }
}