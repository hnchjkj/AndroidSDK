package com.hncj.sdk.pay

import androidx.fragment.app.FragmentActivity
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.pay.network.RequestClient

/**
 * date：2026-01-07 9:28
 * desc：
 */
object CJPaySdk {

    var isInit = false

    fun init() {
        RequestClient.init {
            BillingManager.init(Utils.app)
            isInit = true
        }
    }

    fun startPayment(
        activity: FragmentActivity
    ): PaymentBuilder {
        return PaymentBuilder(activity)
    }
}