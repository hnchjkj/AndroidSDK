package com.hncj.sdk.pay.utils

import com.hncj.sdk.core.utils.LOG
import com.hncj.sdk.pay.network.BusinessException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds
import com.hncj.sdk.pay.network.Result

/**
 * 实现当某个流执行失败时，进行重试，且每次异步操作有时间上限，每次重试的时间上限依次递增
 * 当该流程成功时立刻返回，否则知道重试结束才返回失败结果
 */
internal class FlowRetryUtils(
    private val retryCount: Int = 3,
    private val retryTimeout: Duration = 5.seconds
) {

    private val reachedErrorResult: Result.Error = Result.Error(
        BusinessException(
            Result.Error.ERROR_BUSINESS,
            "max retries reached"
        )
    )

    fun <R> executeWithRetry(
        block: suspend () -> Flow<Result<R>>
    ): Flow<Result<R>> = flow {
        var curCount = 1

        while (curCount <= retryCount) {
            try {
                val result = withTimeoutOrNull(retryTimeout) {
                    LOG.d(LOG.PAY_TAG, "request retry, count: $curCount")
                    block().first()
                }

                when (result) {
                    is Result.Success -> {
                        emit(result)
                        return@flow
                    }

                    is Result.Error -> {
                        LOG.e(LOG.PAY_TAG, "request retry error -> ${result.error}")
                        if (result.error.errorCode == 201) {
                            LOG.d(LOG.PAY_TAG, "request retry 201")
                            emit(result)
                            return@flow
                        }
                        if (curCount < retryCount) {
                            curCount++
                            continue
                        } else {
                            emit(reachedErrorResult)
                            return@flow
                        }
                    }

                    null -> {
                        LOG.e(LOG.PAY_TAG, "request retry error -> internal error")
                        if (curCount < retryCount) {
                            curCount++
                            continue
                        } else {
                            emit(reachedErrorResult)
                            return@flow
                        }
                    }

                    else -> {}
                }
            } catch (e: Exception) {
                e.printStackTrace()
                LOG.e(LOG.PAY_TAG, "request retry exception -> ${e.message}")
                if (curCount < retryCount) {
                    curCount++
                    continue
                } else {
                    emit(reachedErrorResult)
                    return@flow
                }
            }
        }
    }
}