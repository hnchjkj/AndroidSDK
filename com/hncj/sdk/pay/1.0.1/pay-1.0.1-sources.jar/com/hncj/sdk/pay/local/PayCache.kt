package com.hncj.sdk.pay.local

import com.hncj.sdk.core.cache.CacheFactory
import com.hncj.sdk.core.cache.stringCache

/**
 * date：2026-01-15 17:38
 * desc：
 */
internal object PayCache {
    private val cache by lazy {
        CacheFactory.createCache("pay")
    }

    var jsonGooglePaymentRecord by stringCache { cache }
        internal set
}