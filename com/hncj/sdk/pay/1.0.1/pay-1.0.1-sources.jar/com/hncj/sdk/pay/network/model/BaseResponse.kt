package com.hncj.sdk.pay.network.model

import androidx.annotation.Keep

@Keep
internal data class BaseResponse<out T>(
    val code: Int, val msg: String, val data: T
) {
    fun isSuccess() = code == 0 || code == 200
}