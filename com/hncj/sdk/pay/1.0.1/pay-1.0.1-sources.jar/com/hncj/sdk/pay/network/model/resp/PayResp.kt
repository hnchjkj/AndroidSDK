package com.hncj.sdk.pay.network.model.resp

import androidx.annotation.Keep

/**
 * date：2026-01-22 16:14
 * desc：
 */
@Keep
data class PayResp(
    val orderId: String?,
    val redirectUrl: String?
)