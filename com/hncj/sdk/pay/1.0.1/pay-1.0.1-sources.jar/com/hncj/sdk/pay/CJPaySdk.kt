package com.hncj.sdk.pay

import android.util.Log
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.hncj.sdk.pay.R
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.ui.activity.SimpleBrowserActivity
import com.hncj.sdk.core.utils.LoadingDialogHelper
import com.hncj.sdk.core.utils.ToastUtils
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.pay.network.RequestClient
import com.hncj.sdk.pay.network.Result
import com.hncj.sdk.pay.utils.LOG
import com.tencent.mmkv.MMKV
import com.tencent.mmkv.MMKVLogLevel
import kotlinx.coroutines.launch

/**
 * date：2026-01-07 9:28
 * desc：
 */
object CJPaySdk {

    var isDebug = false
    var debugLevel = Log.ERROR

    var isInit = false

    fun init() {
        RequestClient.init {
            BillingManager.init(Utils.app)
            isInit = true
        }
    }

    fun preInit(
        isDebug: Boolean = false,
        debugLevel: Int = Log.ERROR
    ) {
        this.isDebug = isDebug
        this.debugLevel = debugLevel
        LOG.init()
        MMKV.initialize(Utils.app, MMKVLogLevel.LevelError)
    }

    fun startPayment(
        activity: FragmentActivity
    ): PaymentBuilder {
        return PaymentBuilder(activity)
    }
}