package com.hncj.sdk.pay.local.model

import androidx.annotation.Keep

/**
 * date：2026-01-15 17:58
 * desc：
 */
@Keep
internal class GooglePaymentRecord : ArrayList<GooglePaymentRecordItem>()

@Keep
internal data class GooglePaymentRecordItem(
    val orderId: String,
    val productId: String
)