package com.hncj.sdk.pay

import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.hncj.sdk.pay.R
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.ui.activity.SimpleBrowserActivity
import com.hncj.sdk.core.utils.LoadingDialogHelper
import com.hncj.sdk.core.utils.ToastUtils
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.pay.network.RequestClient
import com.hncj.sdk.pay.network.Result
import com.hncj.sdk.pay.utils.LOG
import kotlinx.coroutines.launch

/**
 * date：2026-01-22 16:05
 * desc：
 */
class PaymentBuilder(private val activity: FragmentActivity) {

    private var mPayMode = PayMode.THIRD_PARTY_PAY
    private var mCustomParams = ""
    private var mOrderDesc = ""
    private var mProductId = ""
    private var mProductName = ""
    private var mQuantity = 1
    private var mCurrency = ""
    private var mAmount = ""

    /**
     * 设置参数
     *
     * @param payMode 支付类型
     * @param customParams 唯一标识，例如订单ID，用于回传对应订单
     * @param productId 必须填Google的商品ID
     * @param productName 商品名
     * @param currency 货币 USD\CNY...
     * @param amount 单价
     * @param quantity 数量
     * @param orderDesc 订单描述
     */
    fun setParams(
        payMode: PayMode,
        customParams: String,
        productId: String,
        productName: String,
        currency: String,
        amount: String,
        quantity: Int,
        orderDesc: String
    ): PaymentBuilder {
        mPayMode = payMode
        mCustomParams = customParams
        mProductId = productId
        mProductName = productName
        mCurrency = currency
        mAmount = amount
        mQuantity = quantity
        mOrderDesc = orderDesc
        return this
    }

    fun payment() {
        val loadingDialog = LoadingDialogHelper.getLoadingDialog(activity)
        loadingDialog.show()
        if (CJPaySdk.isInit.not()) {
            loadingDialog.dismiss()
            LOG.e(LOG.TAG_HTTP, "sdk is not initialized")
            return
        }
        activity.lifecycleScope.launch {
            when (
                val result = RequestClient.repository.pay(
                    hashMapOf<String, Any>().apply {
                        put("payMode", mPayMode.modeName)
                        put("customParams", mCustomParams)
                        put("userToken", ConfigCache.token)
                        put("osType", "android")

                        put("productId", mProductId)
                        put("productName", mProductName)
                        put("currency", mCurrency)
                        put("amount", mAmount)
                        put("quantity", mQuantity)
                        put("orderDesc", mOrderDesc)
                    }
                )
            ) {
                is Result.Success -> {
                    loadingDialog.dismiss()
                    if (result.data.redirectUrl.isNullOrEmpty()) {
                        BillingManager.addPaymentRecord(result.data.orderId.orEmpty(), mProductId)
                        BillingManager.doPay(activity, mProductId)
                    } else {
                        SimpleBrowserActivity.start(activity, result.data.redirectUrl)
                    }
                }

                is Result.Error -> {
                    loadingDialog.dismiss()
                    LOG.e(
                        LOG.TAG,
                        "start payment[${mPayMode.modeName}] error, order creation failed."
                    )
                    ToastUtils.showShort(Utils.app.getString(R.string.error_start_pay))
                }

                else -> {}
            }
        }
    }
}