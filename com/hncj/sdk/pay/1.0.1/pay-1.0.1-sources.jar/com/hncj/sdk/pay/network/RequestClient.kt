package com.hncj.sdk.pay.network

import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.pay.network.service.RepositoryImpl
import com.hncj.sdk.pay.network.service.Repository
import com.hncj.sdk.pay.utils.LOG

internal object RequestClient {
    lateinit var repository: Repository

    fun init(callback: () -> Unit) {
        if (ConfigCache.serverDomain.isNotEmpty()) {
            repository = RepositoryImpl(ConfigCache.serverDomain)
            if (::repository.isInitialized) {
                callback.invoke()
            }
        } else {
            LOG.e(LOG.TAG_HTTP, "server init failure, domain is empty")
        }
    }
}