package com.hncj.sdk.pay.network.service

import com.hncj.sdk.pay.network.Result
import com.hncj.sdk.pay.network.model.resp.PayResp
import kotlinx.coroutines.flow.Flow

internal interface Repository {
    suspend fun verify(
        payOrderId: String,
        productId: String,
        orderId: String,
        tokenOrReceipt: String
    ): Flow<Result<Any>>

    suspend fun pay(params: HashMap<String, Any>): Result<PayResp>

    suspend fun isPay(
        orderId: String
    ): Result<Any>
}