package com.hncj.sdk.pay.utils

import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

internal object EncryptUtils {
    fun encrypt(
        path: String,
        body: String,
        appSecret: String
    ): String {
        if (path.isEmpty()) {
            LOG.e(LOG.TAG, "encrypt error, path is empty")
            return ""
        }
        if (body.isEmpty()) {
            LOG.e(LOG.TAG, "encrypt error, body is empty")
            return ""
        }
        if (appSecret.isEmpty()) {
            LOG.e(LOG.TAG, "encrypt error, secret is empty")
            return ""
        }
        val data = path + body
        val mac = Mac.getInstance("HmacSHA256")
        val secretKey = SecretKeySpec(
            appSecret.toByteArray(Charsets.UTF_8),
            "HmacSHA256"
        )
        mac.init(secretKey)
        val rawHmac = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        return rawHmac.toHexLower()
    }

    private fun ByteArray.toHexLower(): String =
        joinToString("") { "%02x".format(it) }
}