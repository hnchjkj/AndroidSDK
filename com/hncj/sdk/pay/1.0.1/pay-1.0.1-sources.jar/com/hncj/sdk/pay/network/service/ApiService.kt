package com.hncj.sdk.pay.network.service

import com.hncj.sdk.pay.network.model.BaseResponse
import com.hncj.sdk.pay.network.model.resp.PayResp
import retrofit2.http.FieldMap
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

internal interface ApiService {

    /**
     * 验证支付
     */
    @FormUrlEncoded
    @POST("/pay/pay/verify")
    suspend fun verify(@FieldMap params: HashMap<String, String>): BaseResponse<Any>

    /**
     * 第三方支付
     */
    @FormUrlEncoded
    @POST("/pay/pay/pay")
    suspend fun pay(@FieldMap params: HashMap<String, Any>): BaseResponse<PayResp>

    /**
     * 第三方支付
     */
    @FormUrlEncoded
    @POST("/pay/pay/isPay")
    suspend fun isPay(@FieldMap params: HashMap<String, String>): BaseResponse<Any>
}