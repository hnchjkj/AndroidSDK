package com.hncj.sdk.pay.network

internal data class BusinessException(
    val errorCode: Int = 0,
    val errorMessage: String? = null
) : Exception(errorMessage)