package com.hncj.sdk.pay

/**
 * date：2026-01-22 16:05
 * desc：
 */
enum class PayMode(val modeName: String) {
    GOOGLE_PAY("google_pay"),
    THIRD_PARTY_PAY("third_pay")
}