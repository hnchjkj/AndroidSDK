package com.hncj.sdk.pay.network

import android.annotation.SuppressLint
import com.hncj.sdk.pay.network.converter.ConverterFactory
import com.hncj.sdk.pay.utils.LOG
import okhttp3.ConnectionPool
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

internal object NetworkFactory {

    fun createRetrofit(url: String): Retrofit {
        return Retrofit.Builder()
            .client(createOkHttpClient())
            .baseUrl(url)
            .addConverterFactory(ConverterFactory())
            .build()
    }

    @SuppressLint("TrustAllX509TrustManager", "CustomX509TrustManager")
    private fun createOkHttpClient(): OkHttpClient {
        // 创建一个信任所有证书的TrustManager
        val trustAllCertificates = arrayOf<javax.net.ssl.TrustManager>(
            object : X509TrustManager {
                override fun checkClientTrusted(
                    chain: Array<out X509Certificate>?,
                    authType: String?
                ) {
                    // 无需实现
                }

                override fun checkServerTrusted(
                    chain: Array<out X509Certificate>?,
                    authType: String?
                ) {
                    // 无需实现
                }

                override fun getAcceptedIssuers(): Array<X509Certificate> {
                    return emptyArray()
                }
            }
        )
        // 设置SSL上下文，将其信任所有证书
        val sslContext = SSLContext.getInstance("TLS")
        sslContext.init(null, trustAllCertificates, java.security.SecureRandom())

        val builder = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(10, TimeUnit.SECONDS)
            .connectionPool(ConnectionPool(10, 5, TimeUnit.MINUTES))
            .sslSocketFactory(sslContext.socketFactory, trustAllCertificates[0] as X509TrustManager)
            .hostnameVerifier { hostname, session -> true } // 接受所有主机名

        // interceptors.
        builder.addInterceptor(RequestInterceptor())
            .addNetworkInterceptor(CacheNetworkInterceptor())
            .addInterceptor(
                HttpLoggingInterceptor { message ->
                    LOG.d(LOG.TAG_HTTP, message)
                }.setLevel(HttpLoggingInterceptor.Level.BODY)
            )

        return builder.build()
    }

    private class CacheNetworkInterceptor : Interceptor {
        override fun intercept(chain: Interceptor.Chain): Response {
            // 无缓存，进行缓存
            val response = chain.proceed(chain.request())
            return response.newBuilder()
                .removeHeader("Pragma")
                // 对请求进行最大60秒的缓存
                .addHeader("Cache-Control", "max-age=60")
                .build()
        }
    }
}