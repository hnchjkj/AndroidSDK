package com.hncj.sdk.pay.network.converter

import com.google.gson.JsonIOException
import com.google.gson.TypeAdapter
import com.google.gson.stream.JsonToken
import com.hncj.sdk.core.ext.gson
import com.hncj.sdk.pay.utils.LOG
import okhttp3.ResponseBody
import retrofit2.Converter
import java.io.IOException
import java.io.Reader

internal class ResponseConverter<T>(private val adapter: TypeAdapter<T>) : Converter<ResponseBody, T> {

    @Throws(IOException::class)
    override fun convert(value: ResponseBody): T? {
        return value.use { responseBody ->
            gsonConvert(responseBody.charStream())
        }
    }

    private fun gsonConvert(reader: Reader): T? {
        val jsonReader = gson.newJsonReader(reader)
        val result = adapter.read(jsonReader)
        if (jsonReader.peek() != JsonToken.END_DOCUMENT) {
            throw JsonIOException("JSON document was not fully consumed.")
        }
        LOG.d(LOG.TAG_HTTP, "response -> ${gson.toJson(result)}")
        return result
    }
}