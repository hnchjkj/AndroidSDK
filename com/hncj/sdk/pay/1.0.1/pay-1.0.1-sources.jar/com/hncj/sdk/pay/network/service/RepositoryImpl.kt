package com.hncj.sdk.pay.network.service

import androidx.annotation.RestrictTo
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.pay.network.NetworkFactory
import com.hncj.sdk.pay.network.ResultTransformer
import com.hncj.sdk.pay.network.Result
import com.hncj.sdk.pay.network.model.resp.PayResp
import kotlinx.coroutines.flow.Flow
import retrofit2.create

@RestrictTo(RestrictTo.Scope.LIBRARY)
internal class RepositoryImpl(url: String) : Repository {

    private val service: ApiService by lazy {
        NetworkFactory.createRetrofit(url).create()
    }

    override suspend fun verify(
        payOrderId: String,
        productId: String,
        orderId: String,
        tokenOrReceipt: String
    ): Flow<Result<Any>> {
        return ResultTransformer.asResultFlow(
            networkCall = {
                val params = hashMapOf<String, String>().apply {
                    put("userToken", ConfigCache.token)
                    put("packageName", Utils.app.applicationInfo.packageName)
                    put("payMode", "google_pay")

                    put("productId", productId)
                    put("orderId", orderId)
                    put("tokenOrReceipt", tokenOrReceipt)

                    put("payOrderId", payOrderId)
                }
                service.verify(params)
            }
        )
    }

    override suspend fun pay(params: HashMap<String, Any>): Result<PayResp> {
        return ResultTransformer.asResult(
            networkCall = {
                service.pay(params)
            },
            transformer = { it }
        )
    }

    override suspend fun isPay(orderId: String): Result<Any> {
        return ResultTransformer.asResult(
            networkCall = {
                val params = hashMapOf<String, String>().apply {
                    put("orderId", orderId)
                }
                service.isPay(params)
            }
        )
    }
}