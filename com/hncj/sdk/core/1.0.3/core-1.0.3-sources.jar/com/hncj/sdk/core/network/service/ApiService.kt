package com.hncj.sdk.core.network.service

import com.hncj.sdk.core.network.model.BaseResponse
import com.hncj.sdk.core.network.model.resp.VendorConfigResp
import retrofit2.http.FieldMap
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

internal interface ApiService {

    @FormUrlEncoded
    @POST("/user/login/queryVendorConfig")
    suspend fun queryVendorConfig(@FieldMap params: HashMap<String, String>): BaseResponse<VendorConfigResp>
}