package com.hncj.sdk.core.utils

import android.app.Application
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

/**
 * date：2026-01-15 13:51
 * desc：
 */
object Utils {
    val mHandler = Handler(Looper.getMainLooper())
    val mCoroutineScope = CoroutineScope(Dispatchers.IO)

    private lateinit var mApplication: Application

    fun init(app: Application) {
        if (::mApplication.isInitialized) return
        mApplication = app
    }

    val app: Application
        get() {
            return mApplication
        }
}