package com.hncj.sdk.core.utils

import android.app.Activity
import android.app.Dialog
import android.view.LayoutInflater
import android.widget.TextView
import com.hncj.sdk.core.R
import com.hncj.sdk.core.views.CustomDialog

/**
 * date：2026-01-20 13:35
 * desc：
 */
object LoadingDialogHelper {
    fun getLoadingDialog(
        activity: Activity,
        content: String? = null
    ): Dialog {
        val loadingDialog = CustomDialog(activity)
        val view = LayoutInflater.from(activity).inflate(R.layout.dialog_loading, null)

        content?.apply {
            if (isNotEmpty()) {
                view.findViewById<TextView>(R.id.must_content_tv)?.text = this
            }
        }

        loadingDialog.setCancelable(false)
        loadingDialog.setCanceledOnTouchOutside(false)
        loadingDialog.setContentView(view)

        return loadingDialog
    }
}