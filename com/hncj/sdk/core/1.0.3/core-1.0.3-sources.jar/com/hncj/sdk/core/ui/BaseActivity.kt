package com.hncj.sdk.core.ui

import android.content.Intent
import android.content.res.Resources
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import com.gyf.immersionbar.ImmersionBar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel

abstract class BaseActivity<DB : ViewDataBinding> : AppCompatActivity(),
    CoroutineScope by MainScope() {

    protected lateinit var mDataBinding: DB

    protected val TAG = javaClass.simpleName
    protected val mHandler by lazy { Handler(Looper.getMainLooper()) }

    private var mStartActivityTag: String? = null
    private var mStartActivityTime: Long = 0

    private var mNeedReloadFeedAd = false
    private var mIsLastShowClass = false

    protected abstract fun getLayoutId(): Int
    protected abstract fun initViews()
    protected abstract fun initDataObserver()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mDataBinding = DataBindingUtil.inflate(layoutInflater, getLayoutId(), null, false)
        setContentView(mDataBinding.root)

        mDataBinding.lifecycleOwner = this

        ImmersionBar.with(this)
            .statusBarDarkFont(statusBarDarkFont())
            .init()

        initViews()
        initDataObserver()
    }

    override fun onPause() {
        super.onPause()
        mIsLastShowClass = false
    }

    override fun onDestroy() {
        // 取消当前Activity的协程
        cancel()
        super.onDestroy()
    }

    open fun statusBarDarkFont(): Boolean {
        return true
    }

    override fun getResources(): Resources {
        val resources = super.getResources()
        val configuration = resources.configuration
        if (configuration.fontScale != 1.0F) {
            configuration.fontScale = 1.0F
            resources.updateConfiguration(configuration, resources.displayMetrics)
        }
        return resources
    }

    /**
     * 防 Activity 多重跳转
     */
    override fun startActivityForResult(intent: Intent, requestCode: Int, options: Bundle?) {
        if (startActivitySelfCheck(intent)) {
            // 查看源码得知 startActivity 最终也会调用 startActivityForResult
            super.startActivityForResult(intent, requestCode, options)
        }
    }

    /**
     * 检查当前 Activity 是否重复跳转了，不需要检查则重写此方法并返回 true 即可
     */
    protected fun startActivitySelfCheck(intent: Intent): Boolean {
        // 默认检查通过
        var result = true
        // 标记对象
        val tag = when {
            intent.component != null -> {
                // 显式跳转
                intent.component!!.className
            }

            intent.action != null -> {
                // 隐式跳转
                intent.action!!
            }

            else -> {
                // 其他方式
                return true
            }
        }

        if (tag == mStartActivityTag && mStartActivityTime >= SystemClock.uptimeMillis() - 500) {
            // 检查不通过
            result = false
        }

        mStartActivityTag = tag
        mStartActivityTime = SystemClock.uptimeMillis()
        return result
    }
}