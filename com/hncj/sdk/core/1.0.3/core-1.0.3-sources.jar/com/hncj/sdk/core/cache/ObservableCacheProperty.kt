package com.hncj.sdk.core.cache

import androidx.annotation.RestrictTo
import com.hncj.sdk.core.utils.LOG
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

@RestrictTo(RestrictTo.Scope.LIBRARY)
abstract class ObservableCacheProperty<V>() :
    ReadWriteProperty<Any?, V> {


    /**
     *  The callback which is called before a change to the property value is attempted.
     *  The value of the property hasn't been changed yet, when this callback is invoked.
     *  If the callback returns `true` the value of the property is being set to the new value,
     *  and if the callback returns `false` the new value is discarded and the property remains its old value.
     */
    protected open fun beforeChange(property: KProperty<*>, oldValue: V, newValue: V): Boolean =
        true

    /**
     * The callback which is called after the change of the property is made. The value of the property
     * has already been changed when this callback is invoked.
     */
    protected open fun afterChange(property: KProperty<*>, oldValue: V, newValue: V): Unit {}
}

@RestrictTo(RestrictTo.Scope.LIBRARY)
class BoolObservableCacheProperty(
    private val defaultValue: Boolean = false,
    private val onValueChanged: (newValue: Boolean) -> Unit,
    private val cacheProvider: () -> Cache<String>
) : ObservableCacheProperty<Boolean>() {

    override fun beforeChange(
        property: KProperty<*>,
        oldValue: Boolean,
        newValue: Boolean
    ): Boolean {
        return oldValue != newValue
    }

    override fun afterChange(property: KProperty<*>, oldValue: Boolean, newValue: Boolean) {
        LOG.d(LOG.TAG_MMKV, "Property[${property.name}] Change: $oldValue -> $newValue")
        onValueChanged(newValue)
    }

    override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean {
        return cacheProvider().getOrDefault(property.name, defaultValue)
    }

    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
        val oldValue = getValue(thisRef, property)
        if (!beforeChange(property, oldValue, value)) {
            return
        }
        cacheProvider().set(property.name, value)
        afterChange(property, oldValue, value)
    }
}

@RestrictTo(RestrictTo.Scope.LIBRARY)
class StringObservableCacheProperty(
    private val defaultValue: String = "",
    private val onValueChanged: (newValue: String) -> Unit,
    private val cacheProvider: () -> Cache<String>
) : ObservableCacheProperty<String>() {

    override fun beforeChange(
        property: KProperty<*>,
        oldValue: String,
        newValue: String
    ): Boolean {
        return oldValue != newValue
    }

    override fun afterChange(
        property: KProperty<*>,
        oldValue: String,
        newValue: String
    ) {
        LOG.d(LOG.TAG_MMKV, "Property[${property.name}] Change: $oldValue -> $newValue")
        onValueChanged(newValue)
    }

    override fun setValue(
        thisRef: Any?,
        property: KProperty<*>,
        value: String
    ) {
        val oldValue = getValue(thisRef, property)
        if (!beforeChange(property, oldValue, value)) {
            return
        }
        cacheProvider().set(property.name, value)
        afterChange(property, oldValue, value)
    }

    override fun getValue(
        thisRef: Any?,
        property: KProperty<*>
    ): String {
        return cacheProvider().getOrDefault(property.name, defaultValue)
    }
}