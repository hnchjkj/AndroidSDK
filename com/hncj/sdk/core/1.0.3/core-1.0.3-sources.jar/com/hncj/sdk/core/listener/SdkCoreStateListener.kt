package com.hncj.sdk.core.listener

/**
 * date：2026-01-15 11:28
 * desc：
 */
interface SdkCoreStateListener {
    fun onInitSuccess()
    fun onInitFailed(code: Int = -1, msg: String = "") {}
}