package com.hncj.sdk.core.ui.activity

import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Log
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.ProgressBar
import androidx.core.animation.addListener
import com.hncj.sdk.core.R
import com.hncj.sdk.core.databinding.ActivitySimpleBrowserBinding
import com.hncj.sdk.core.ext.gone
import com.hncj.sdk.core.ext.onThrottleClick
import com.hncj.sdk.core.ext.visible
import com.hncj.sdk.core.ui.BaseActivity
import com.hncj.sdk.core.views.SimpleWebView
import com.qmuiteam.qmui.widget.webview.QMUIWebViewClient

class SimpleBrowserActivity : BaseActivity<ActivitySimpleBrowserBinding>() {

    companion object {
        private const val KEY_URL = "url"
        private const val KEY_TITLE = "title"

        fun start(context: Context, url: String, title: String? = null) {
            context.startActivity(
                Intent(context, SimpleBrowserActivity::class.java).apply {
                    putExtra(KEY_URL, url)
                    putExtra(KEY_TITLE, title)
                }
            )
        }
    }

    private lateinit var mSimpleWebView: SimpleWebView
    private lateinit var mProgressHandler: ProgressHandler
    private var mTitle: String? = null

    override fun initViews() {
        val url = intent.getStringExtra(KEY_URL) ?: ""
        mTitle = intent.getStringExtra(KEY_TITLE)
        updateTitle(mTitle)

        mProgressHandler = ProgressHandler(mDataBinding.mustProgressBar)
        // init web view
        mSimpleWebView = SimpleWebView(this)

        mSimpleWebView.addJavascriptInterface(
            JsBridge(this),
            "Android"
        )

        mSimpleWebView.webChromeClient = HookWebViewChromeClient()
        mSimpleWebView.webViewClient = HookWebViewClient()
        mSimpleWebView.requestFocus(View.FOCUS_DOWN)

        mDataBinding.mustWebViewContainer.addView(mSimpleWebView)
//        mDataBinding.mustWebViewContainer.addWebView(mSimpleWebView, false)

        mDataBinding.mustBackAny.onThrottleClick {
            finish()
        }

        if (url.isNotEmpty()) {
            mSimpleWebView.loadUrl(url)
        }

        showLoading()
    }

    private fun showLoading() {
        mDataBinding.mustLoadingView.visible()
    }

    private fun hideLoading() {
        mDataBinding.mustLoadingView.gone()
    }

    private fun updateTitle(title: String?) {
        if (title.isNullOrEmpty()) return
        this.title = title
        mDataBinding.mustTitleTv.text = title
    }

    private fun sendProgressMsg(msgType: Int, progress: Int, duration: Int) {
        val msg = Message.obtain(mProgressHandler)
        msg.what = msgType
        msg.arg1 = progress
        msg.arg2 = duration

        mProgressHandler.sendMessage(msg)
    }

    private inner class HookWebViewChromeClient : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            super.onProgressChanged(view, newProgress)
            if (newProgress > mDataBinding.mustProgressBar.progress) {
                sendProgressMsg(ProgressHandler.PROGRESS_PROCESS, newProgress, 100)
            }
        }

        override fun onReceivedTitle(view: WebView?, title: String?) {
            super.onReceivedTitle(view, title)
            if (mTitle.isNullOrEmpty()) {
                updateTitle(title)
            }
        }

        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
            callback?.onCustomViewHidden()
        }
    }

    private inner class HookWebViewClient : QMUIWebViewClient(false, true) {
        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
            if (title.isNullOrEmpty()) {
                updateTitle(view?.title)
            }

            if (mDataBinding.mustProgressBar.progress == 0) {
                sendProgressMsg(ProgressHandler.PROGRESS_PROCESS, 30, 500)
            }
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            hideLoading()
            sendProgressMsg(ProgressHandler.PROGRESS_GONE, 100, 0)
            if (title.isNullOrEmpty()) {
                updateTitle(view?.title)
            }
        }
    }

    private class ProgressHandler(
        private val progressBar: ProgressBar,
        looper: Looper = Looper.getMainLooper()
    ) : Handler(looper) {
        companion object {
            internal const val PROGRESS_PROCESS = 1
            internal const val PROGRESS_GONE = 2
        }

        private var dstProgressIndex: Int = 0
        private var progressDuration = 0
        private var animator: ObjectAnimator? = null

        override fun handleMessage(msg: Message) {
            when (msg.what) {
                PROGRESS_PROCESS -> {
                    dstProgressIndex = msg.arg1
                    progressDuration = msg.arg2
                    progressBar.visibility = View.VISIBLE
                    if (animator?.isRunning == true) {
                        animator?.cancel()
                    }

                    animator =
                        ObjectAnimator.ofInt(progressBar, "progress", dstProgressIndex).apply {
                            duration = progressDuration.toLong()
                            addListener(onEnd = {
                                if (progressBar.progress == 100) {
                                    sendEmptyMessageDelayed(PROGRESS_GONE, 500)
                                }
                            })
                        }

                    animator?.start()
                }

                PROGRESS_GONE -> {
                    dstProgressIndex = 0
                    progressDuration = 0
                    progressBar.progress = 0
                    progressBar.visibility = View.GONE
                    if (animator?.isRunning == true) {
                        animator?.cancel()
                    }

                    animator = ObjectAnimator.ofInt(progressBar, "progress", 0).apply {
                        duration = 0L
                        removeAllListeners()
                    }
                }

                else -> {
                    // do nothing.
                }
            }
        }
    }

    override fun initDataObserver() {}

    override fun getLayoutId(): Int {
        return R.layout.activity_simple_browser
    }
}