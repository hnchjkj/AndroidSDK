package com.hncj.sdk.core.utils

import android.widget.Toast

/**
 * date：2026-01-15 13:39
 * desc：
 */
object ToastUtils {
    fun showShort(text: String) {
        Utils.mHandler.post {
            Toast.makeText(Utils.app, text, Toast.LENGTH_SHORT).show()
        }
    }

    fun showLong(text: String) {
        Utils.mHandler.post {
            Toast.makeText(Utils.app, text, Toast.LENGTH_LONG).show()
        }
    }
}