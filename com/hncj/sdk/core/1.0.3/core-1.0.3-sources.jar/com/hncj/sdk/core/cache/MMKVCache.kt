package com.hncj.sdk.core.cache

import com.hncj.sdk.core.utils.LOG
import com.tencent.mmkv.MMKV

internal class MMKVCache(private val kv: MMKV) : Cache<String> {

    override fun set(key: String, value: Int?): Boolean {
        LOG.d(LOG.TAG_MMKV, "set $value to $key")
        return if (value == null) remove(key) else kv.encode(key, value)
    }

    override fun set(key: String, value: Float?): Boolean {
        LOG.d(LOG.TAG_MMKV, "set $value to $key")
        return if (value == null) remove(key) else kv.encode(key, value)
    }

    override fun set(key: String, value: String?): Boolean {
        LOG.d(LOG.TAG_MMKV, "set $value to $key")
        return kv.encode(key, value)
    }

    override fun set(key: String, value: Long?): Boolean {
        LOG.d(LOG.TAG_MMKV, "set $value to $key")
        return if (value == null) remove(key) else kv.encode(key, value)
    }

    override fun set(key: String, value: Boolean?): Boolean {
        LOG.d(LOG.TAG_MMKV, "set $value to $key")
        return if (value == null) remove(key) else kv.encode(key, value)
    }

    override fun getOrDefault(key: String, defaultValue: Boolean): Boolean {
        return kv.decodeBool(key, defaultValue)
    }

    override fun getBooleanOrNull(key: String): Boolean {
        return kv.decodeBool(key)
    }

    override fun getOrDefault(key: String, defaultValue: Int): Int {
        return kv.decodeInt(key, defaultValue)
    }

    override fun getOrDefault(key: String, defaultValue: Float): Float {
        return kv.decodeFloat(key, defaultValue)
    }

    override fun getOrDefault(key: String, defaultValue: String): String {
        return kv.decodeString(key, defaultValue) ?: defaultValue
    }

    override fun getOrDefault(key: String, defaultValue: Long): Long {
        return kv.decodeLong(key, defaultValue)
    }

    override fun getIntOrNull(key: String): Int {
        return kv.decodeInt(key)
    }

    override fun getFloatOrNull(key: String): Float {
        return kv.decodeFloat(key)
    }

    override fun getStringOrNull(key: String): String? {
        return kv.decodeString(key)
    }

    override fun getLongOrNull(key: String): Long {
        return kv.decodeLong(key)
    }

    override fun clear() {
        kv.clearAll()
    }

    override fun remove(key: String): Boolean {
        kv.removeValueForKey(key)
        return true
    }
}