package com.hncj.sdk.core.cache

import androidx.annotation.RestrictTo
import com.hncj.sdk.core.cache.Cache
import java.util.concurrent.ConcurrentHashMap

@RestrictTo(RestrictTo.Scope.LIBRARY)
class MemoryCache : Cache<String> {

    private val map = ConcurrentHashMap<String, Any>()
    override fun set(key: String, value: Int?): Boolean {
        if (value == null) {
            remove(key)
        } else {
            map[key] = value
        }
        return true
    }

    override fun set(key: String, value: Float?): Boolean {
        if (value == null) {
            remove(key)
        } else {
            map[key] = value
        }
        return true
    }

    override fun set(key: String, value: String?): Boolean {
        if (value == null) {
            remove(key)
        } else {
            map[key] = value
        }
        return true
    }

    override fun set(key: String, value: Long?): Boolean {
        if (value == null) {
            remove(key)
        } else {
            map[key] = value
        }
        return true
    }

    override fun set(key: String, value: Boolean?): Boolean {
        if (value == null) {
            remove(key)
        } else {
            map[key] = value
        }
        return true
    }

    override fun getOrDefault(key: String, defaultValue: Int): Int {
        val result = map.getOrDefault(key, defaultValue)
        return if (result is Int) result else defaultValue
    }

    override fun getOrDefault(key: String, defaultValue: Float): Float {
        val result = map.getOrDefault(key, defaultValue)
        return if (result is Float) result else defaultValue
    }

    override fun getOrDefault(key: String, defaultValue: String): String {
        val result = map.getOrDefault(key, defaultValue)
        return if (result is String) result else defaultValue
    }

    override fun getOrDefault(key: String, defaultValue: Long): Long {
        val result = map.getOrDefault(key, defaultValue)
        return if (result is Long) result else defaultValue
    }

    override fun getOrDefault(key: String, defaultValue: Boolean): Boolean {
        val result = map.getOrDefault(key, defaultValue)
        return if (result is Boolean) result else defaultValue
    }

    override fun getIntOrNull(key: String): Int? {
        return map[key] as? Int?
    }

    override fun getFloatOrNull(key: String): Float? {
        return map[key] as? Float?
    }

    override fun getStringOrNull(key: String): String? {
        return map[key] as? String?
    }

    override fun getLongOrNull(key: String): Long? {
        return map[key] as? Long?
    }

    override fun getBooleanOrNull(key: String): Boolean? {
        return map[key] as? Boolean?
    }

    override fun clear() {
        map.clear()
    }

    override fun remove(key: String): Boolean {
        map.remove(key)
        return true
    }
}