package com.hncj.sdk.core.views

import android.app.Dialog
import android.content.Context
import android.view.WindowManager
import com.hncj.sdk.core.R

class CustomDialog(context: Context) : Dialog(context, R.style.CustomDialogStyle) {
    override fun show() {
        window?.apply {
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT
            )
            addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            setDimAmount(0F)
        }
        super.show()
    }
}