package com.hncj.sdk.core.cache

import androidx.annotation.RestrictTo
import kotlin.properties.PropertyDelegateProvider
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

private fun intDelegateProvider(defaultValue: Int, cacheProvider: () -> Cache<String>) =
    PropertyDelegateProvider<Any?, ReadWriteProperty<Any?, Int>> { _, _ ->
        object : ReadWriteProperty<Any?, Int> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): Int {
                return cacheProvider().getOrDefault(property.name, defaultValue)
            }

            override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
                cacheProvider().set(property.name, value)
            }
        }
    }

@RestrictTo(RestrictTo.Scope.LIBRARY)
val intCache = fun(cacheProvider: () -> Cache<String>) = intDelegateProvider(0, cacheProvider)

@RestrictTo(RestrictTo.Scope.LIBRARY)
val intCacheWithDefault = fun(defaultValue: Int, cacheProvider: () -> Cache<String>) =
    intDelegateProvider(defaultValue, cacheProvider)

@RestrictTo(RestrictTo.Scope.LIBRARY)
val floatCache = fun(cacheProvider: () -> Cache<String>) =
    PropertyDelegateProvider<Any?, ReadWriteProperty<Any?, Float>> { _, _ ->
        object : ReadWriteProperty<Any?, Float> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): Float {
                return cacheProvider().getOrDefault(property.name, 0f)
            }

            override fun setValue(thisRef: Any?, property: KProperty<*>, value: Float) {
                cacheProvider().set(property.name, value)
            }
        }
    }

@RestrictTo(RestrictTo.Scope.LIBRARY)
val nullableStringCache = fun(cacheProvider: () -> Cache<String>) =
    PropertyDelegateProvider<Any?, ReadWriteProperty<Any?, String?>> { _, _ ->
        object : ReadWriteProperty<Any?, String?> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): String? {
                return cacheProvider().getStringOrNull(property.name)
            }

            override fun setValue(thisRef: Any?, property: KProperty<*>, value: String?) {
                cacheProvider().set(property.name, value)
            }
        }
    }


@RestrictTo(RestrictTo.Scope.LIBRARY)
val stringCache = fun(cacheProvider: () -> Cache<String>) =
    PropertyDelegateProvider<Any?, ReadWriteProperty<Any?, String>> { _, _ ->
        object : ReadWriteProperty<Any?, String> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): String {
                return cacheProvider().getOrDefault(property.name, "")
            }

            override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
                cacheProvider().set(property.name, value)
            }
        }
    }

@RestrictTo(RestrictTo.Scope.LIBRARY)
val longCache = fun(cacheProvider: () -> Cache<String>) =
    PropertyDelegateProvider<Any?, ReadWriteProperty<Any?, Long>> { _, _ ->
        object : ReadWriteProperty<Any?, Long> {
            override fun getValue(thisRef: Any?, property: KProperty<*>): Long {
                return cacheProvider().getOrDefault(property.name, 0L)
            }

            override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) {
                cacheProvider().set(property.name, value)
            }
        }
    }

private fun boolDelegateProvider(
    defaultValue: Boolean = false, cacheProvider: () -> Cache<String>
) = PropertyDelegateProvider<Any?, ReadWriteProperty<Any?, Boolean>> { _, _ ->
    object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean {
            return cacheProvider().getOrDefault(property.name, defaultValue)
        }

        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
            cacheProvider().set(property.name, value)
        }
    }
}

@RestrictTo(RestrictTo.Scope.LIBRARY)
val boolCache = fun(cacheProvider: () -> Cache<String>) = boolDelegateProvider(false, cacheProvider)

@RestrictTo(RestrictTo.Scope.LIBRARY)
val boolCacheWithDefault = fun(defaultValue: Boolean, cacheProvider: () -> Cache<String>) =
    boolDelegateProvider(defaultValue, cacheProvider)

@RestrictTo(RestrictTo.Scope.LIBRARY)
val observableBoolCache = fun(
    defaultValue: Boolean,
    onValueChanged: (newValue: Boolean) -> Unit,
    cacheProvider: () -> Cache<String>
) = PropertyDelegateProvider<Any?, ReadWriteProperty<Any?, Boolean>> { _, _ ->
    BoolObservableCacheProperty(defaultValue, onValueChanged, cacheProvider)
}

@RestrictTo(RestrictTo.Scope.LIBRARY)
val observableStringCache = fun(
    defaultValue: String,
    onValueChanged: (newValue: String) -> Unit,
    cacheProvider: () -> Cache<String>
) = PropertyDelegateProvider<Any?, ReadWriteProperty<Any?, String>> { _, _ ->
    StringObservableCacheProperty(defaultValue, onValueChanged, cacheProvider)
}