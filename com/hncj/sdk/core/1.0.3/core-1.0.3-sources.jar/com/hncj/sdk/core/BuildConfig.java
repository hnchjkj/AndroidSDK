/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.hncj.sdk.core;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.hncj.sdk.core";
  public static final String BUILD_TYPE = "release";
}
