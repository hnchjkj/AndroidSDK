package com.hncj.sdk.core.network

import com.hncj.sdk.core.network.service.RepositoryImpl
import com.hncj.sdk.core.network.service.Repository

internal object RequestClient {
    val repository: Repository by lazy { RepositoryImpl() }
}