package com.hncj.sdk.core.cache

interface Cache<K> {
    fun set(key: K, value: Int?): Boolean
    fun set(key: K, value: Float?): Boolean
    fun set(key: K, value: String?): Boolean
    fun set(key: K, value: Long?): Boolean
    fun set(key: K, value: Boolean?): Boolean
    fun getOrDefault(key: K, defaultValue: Int): Int
    fun getOrDefault(key: K, defaultValue: Float): Float
    fun getOrDefault(key: K, defaultValue: String): String
    fun getOrDefault(key: K, defaultValue: Long): Long
    fun getOrDefault(key: K, defaultValue: Boolean): Boolean
    fun getIntOrNull(key: K): Int?
    fun getFloatOrNull(key: K): Float?
    fun getStringOrNull(key: K): String?
    fun getLongOrNull(key: K): Long?
    fun getBooleanOrNull(key: K): Boolean?
    fun clear()
    fun remove(key: K): Boolean
}