package com.hncj.sdk.core.network.model.resp

import androidx.annotation.Keep
import com.hncj.sdk.core.config.ConfigCache

/**
 * date：2026-01-15 10:12
 * desc：
 */
@Keep
internal data class VendorConfigResp(
    val serverDomain: String, // 服务器域名
    val userAgreement: String, // 用户协议地址
    val privacyAgreement: String, // 隐私协议地址
    val vendorLoginConfigList: ArrayList<VendorLoginConfig>,
    val vendorPayConfigList: ArrayList<VendorPayConfig>
) {
    fun save() {
        ConfigCache.serverDomain = serverDomain
        ConfigCache.userAgreement = userAgreement
        ConfigCache.privacyAgreement = privacyAgreement
        ConfigCache.setVendorLoginConfigList(vendorLoginConfigList)
        ConfigCache.setVendorPayConfigList(vendorPayConfigList)
    }
}

@Keep
internal class ListVendorLoginConfig : ArrayList<VendorLoginConfig>()
@Keep
data class VendorLoginConfig(
    val clientId: String, // 客户端ID
    val clientSecret: String, // 客户端密钥
    val extraParams: String, // 其他参数(JSON格式)
    val loginType: String, // 登录类型(google/apple/facebook/twitter/line/naver/email/guest)
    val loginTypeDesc: String, // 登录类型描述
    val loginTypeIcon: String, // 图标
    val redirectUri: String // 回调地址
)

@Keep
internal class ListVendorPayConfig : ArrayList<VendorPayConfig>()
@Keep
data class VendorPayConfig(
    val extraParams: String, // 其他参数(JSON格式)
    val merchantId: String, // 商户ID
    val merchantKey: String, // 商户密钥
    val payChannel: String, // 支付渠道(第三方支付时使用)
    val payType: String, // 支付类型(google/apple/third_party)
    val payTypeIcon: String, // 支付图标
    val payTypeName: String, // 支付类型名
    val pay_notifyUrl: String, // 支付回调地址
    val privateKey: String, // 私钥
    val publicKey: String, // 公钥
    val refundNotifyUrl: String // 退款回调地址
)