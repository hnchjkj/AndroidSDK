package com.hncj.sdk.core.network.service

import androidx.annotation.RestrictTo
import com.hncj.sdk.core.network.NetworkFactory
import com.hncj.sdk.core.network.Result
import com.hncj.sdk.core.network.ResultTransformer
import com.hncj.sdk.core.network.model.resp.VendorConfigResp
import kotlinx.coroutines.flow.Flow
import retrofit2.create

@RestrictTo(RestrictTo.Scope.LIBRARY)
internal class RepositoryImpl : Repository {

    private val service: ApiService by lazy { NetworkFactory.createRetrofit().create() }

    override suspend fun queryVendorConfig(): Flow<Result<VendorConfigResp>> {
        return ResultTransformer.asResultFlow(
            networkCall = {
                val params = hashMapOf<String, String>().apply {

                }
                service.queryVendorConfig(params)
            },
            successCall = {
                // 请求成功回调，这里可以做参数保存
                it.data.save()
            }
        )
    }
}