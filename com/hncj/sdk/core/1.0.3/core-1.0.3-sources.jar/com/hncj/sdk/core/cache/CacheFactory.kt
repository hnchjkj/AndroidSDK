package com.hncj.sdk.core.cache

import androidx.annotation.RestrictTo
import com.tencent.mmkv.MMKV

@RestrictTo(RestrictTo.Scope.LIBRARY)
object CacheFactory {

    // 用于存储本地的一些缓存数据
    val localCache: Cache<String> by lazy {
        MMKVCache(MMKV.defaultMMKV())
    }

    val memoryCache: Cache<String> by lazy {
        MemoryCache()
    }

    fun createCache(name: String): Cache<String> {
        return MMKVCache(MMKV.mmkvWithID(name))
    }
}