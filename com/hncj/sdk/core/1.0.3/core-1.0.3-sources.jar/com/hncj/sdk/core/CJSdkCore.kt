package com.hncj.sdk.core

import android.app.Application
import android.util.Log
import com.hncj.sdk.core.config.ConfigCache
import com.hncj.sdk.core.listener.SdkCoreStateListener
import com.hncj.sdk.core.network.RequestClient
import com.hncj.sdk.core.utils.LOG
import com.tencent.mmkv.MMKV
import com.tencent.mmkv.MMKVLogLevel
import kotlinx.coroutines.launch
import com.hncj.sdk.core.network.Result
import com.hncj.sdk.core.utils.FlowRetryUtils
import com.hncj.sdk.core.utils.Utils
import com.hncj.sdk.core.utils.Utils.app
import com.qmuiteam.qmui.arch.QMUISwipeBackActivityManager
import kotlinx.coroutines.flow.collectLatest
import java.util.UUID

/**
 * date：2026-01-07 9:28
 * desc：
 */
object CJSdkCore {

    var isDebug = false
    var debugLevel = Log.ERROR

    /**
     * 初始化
     */
    fun init(
        application: Application,
        appKey: String,
        appSecret: String,
        sdkCoreStateListener: SdkCoreStateListener,
        isDebug: Boolean = false,
        debugLevel: Int = Log.ERROR
    ) {
        this.isDebug = isDebug
        this.debugLevel = debugLevel
        Utils.init(application)
        LOG.init()
        MMKV.initialize(application, MMKVLogLevel.LevelError)
        QMUISwipeBackActivityManager.init(application)

        ConfigCache.appKey = appKey
        ConfigCache.appSecret = appSecret
        if (ConfigCache.uuid.isEmpty()) {
            ConfigCache.uuid = UUID.randomUUID().toString()
        }

        Utils.mCoroutineScope.launch {
            FlowRetryUtils().executeWithRetry { RequestClient.repository.queryVendorConfig() }
                .collectLatest {
                    when (it) {
                        is Result.Success -> {
                            LOG.d(LOG.TAG_HTTP, "queryVendorConfig -> success")
                            sdkCoreStateListener.onInitSuccess()
                        }

                        is Result.Error -> {
                            LOG.e(
                                LOG.TAG_HTTP,
                                "queryVendorConfig -> error, ${it.error.errorMessage}"
                            )
                            sdkCoreStateListener.onInitFailed(
                                it.error.errorCode,
                                it.error.errorMessage.orEmpty()
                            )
                        }

                        else -> {}
                    }
                }
        }
    }
}