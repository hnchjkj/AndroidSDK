package com.hncj.sdk.core;

@androidx.databinding.BindingBuildInfo
public class DataBindingTriggerClass {}