package com.hncj.sdk.core.config

import androidx.annotation.Keep
import com.hncj.sdk.core.cache.CacheFactory
import com.hncj.sdk.core.cache.observableStringCache
import com.hncj.sdk.core.cache.stringCache
import com.hncj.sdk.core.ext.gson
import com.hncj.sdk.core.network.model.resp.ListVendorLoginConfig
import com.hncj.sdk.core.network.model.resp.ListVendorPayConfig
import com.hncj.sdk.core.network.model.resp.VendorLoginConfig
import com.hncj.sdk.core.network.model.resp.VendorPayConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

@Keep
object ConfigCache {

    private val cache by lazy {
        CacheFactory.createCache("appConfig")
    }

    /**
     * 用户应用的AppKey
     */
    var appKey by stringCache { cache }
        internal set

    /**
     * 用户的token
     */
    var token by stringCache { cache }

    /**
     * 用户应用的AppSecret
     */
    var appSecret by stringCache { cache }
        internal set

    /**
     * 用户的UUID
     */
    var uuid by stringCache { cache }
        internal set

    /**
     * 用户应用的服务器域名
     */
    var serverDomain by stringCache { cache }
        internal set

    var userAgreement by stringCache { cache }
        internal set

    var privacyAgreement by stringCache { cache }
        internal set

    var jsonStrVendorLoginConfigList by stringCache { cache }
        internal set

    fun setVendorLoginConfigList(data: ArrayList<VendorLoginConfig>) {
        jsonStrVendorLoginConfigList = gson.toJson(data)
    }

    fun getVendorLoginConfigList(): ArrayList<VendorLoginConfig> {
        val localJson = jsonStrVendorLoginConfigList.ifEmpty { "[]" }
        return gson.fromJson(localJson, ListVendorLoginConfig::class.java)
    }

    var jsonStrVendorPayConfigList by stringCache { cache }
        internal set

    fun setVendorPayConfigList(data: ArrayList<VendorPayConfig>) {
        jsonStrVendorPayConfigList = gson.toJson(data)
    }

    fun getVendorPayConfigList(): ArrayList<VendorPayConfig> {
        val localJson = jsonStrVendorPayConfigList.ifEmpty { "[]" }
        return gson.fromJson(localJson, ListVendorPayConfig::class.java)
    }
}