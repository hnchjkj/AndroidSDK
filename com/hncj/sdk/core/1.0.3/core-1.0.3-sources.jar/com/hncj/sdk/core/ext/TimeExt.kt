package com.hncj.sdk.core.ext

fun currentSeconds(): Long {
    return System.currentTimeMillis() / 1000
}