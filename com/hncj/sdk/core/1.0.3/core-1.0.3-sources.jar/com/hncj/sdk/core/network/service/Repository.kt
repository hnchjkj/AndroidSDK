package com.hncj.sdk.core.network.service

import com.hncj.sdk.core.network.Result
import com.hncj.sdk.core.network.model.resp.VendorConfigResp
import kotlinx.coroutines.flow.Flow

internal interface Repository {
    suspend fun queryVendorConfig(): Flow<Result<VendorConfigResp>>
}