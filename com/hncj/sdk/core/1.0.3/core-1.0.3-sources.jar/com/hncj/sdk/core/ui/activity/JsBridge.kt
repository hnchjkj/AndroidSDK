package com.hncj.sdk.core.ui.activity

import android.app.Activity
import android.webkit.JavascriptInterface

/**
 * date：2026-01-22 15:17
 * desc：
 */
class JsBridge(private val activity: Activity) {
    @JavascriptInterface
    fun callNative(json: String?) {
        activity.runOnUiThread {
            activity.finish()
        }
    }
}