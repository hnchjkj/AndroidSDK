package com.hncj.sdk.core.ext

import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity

fun Fragment.toast(
    text: CharSequence?
) {
    requireActivity().toast(text)
}

fun FragmentActivity.toast(
    text: CharSequence?
) {
    if (text.isNullOrEmpty()) return
    Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}